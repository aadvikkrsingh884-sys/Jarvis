package com.jarvis.assistant

import android.content.Context
import android.graphics.*
import android.view.View
import androidx.core.graphics.PathParser
import kotlin.math.*

/**
 * The avatar: an original anime-boy character drawn from vector art (blinks, lip-syncs, shows moods, tilts),
 * or one of your own images (up to 4 slots) with framing and a glowing outline.
 */
class AvatarView(ctx: Context) : View(ctx) {
    var accent = 0xFFC9A227.toInt()
    var state = "idle"
    var emotion = "neutral"
    var photo: Bitmap? = null
    var framing = "full"
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val paths = AnimeArt.P.mapValues { PathParser.createPathFromPathData(it.value) }
    private var t = 0f
    private fun a(c: Int, al: Int) = Color.argb(al, Color.red(c), Color.green(c), Color.blue(c))

    override fun onDraw(c: Canvas) {
        t += 0.045f
        val w = width.toFloat(); val h = height.toFloat(); val cx = w / 2f; val s = min(w, h); val sp = state == "speaking"
        p.style = Paint.Style.FILL; p.shader = RadialGradient(cx, h * 0.5f, s * 0.7f, a(accent, if (sp) 120 else 60), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        c.drawCircle(cx, h * 0.5f, s * 0.7f, p); p.shader = null
        val b = photo
        if (b != null) {
            val fr = when (framing) { "upper" -> 0.55f; "face" -> 0.3f; else -> 1f }
            val sh = (b.height * fr).toInt().coerceAtLeast(1)
            val k = min(w * 0.92f / b.width, h * 0.98f / sh) * (1f + (if (sp) 0.02f * sin(t * 8f) else 0.008f * sin(t)))
            val iw = b.width * k; val ih = sh * k; val dst = RectF(cx - iw / 2, h / 2 - ih / 2, cx + iw / 2, h / 2 + ih / 2)
            p.alpha = 255; c.drawBitmap(b, Rect(0, 0, b.width, sh), dst, p)
        } else drawAnime(c, w, h)
        postInvalidateOnAnimation()
    }

    private fun fill(c: Canvas, k: String, col: Int) { p.style = Paint.Style.FILL; p.color = col; c.drawPath(paths[k]!!, p) }
    private fun line(c: Canvas, k: String, col: Int, wd: Float, al: Int = 255) { p.style = Paint.Style.STROKE; p.strokeWidth = wd; p.strokeCap = Paint.Cap.ROUND; p.color = a(col, al); c.drawPath(paths[k]!!, p) }
    private fun dot(c: Canvas, x: Float, y: Float, r: Float, col: Int) { p.style = Paint.Style.FILL; p.color = col; c.drawCircle(x, y, r, p) }

    private fun drawAnime(c: Canvas, w: Float, h: Float) {
        val sc = h / 480f; val sp = state == "speaking"; val hair = 0xFF1B1F3A.toInt()
        c.save(); c.translate((w - 400 * sc) / 2 + sin(t * 0.7f) * 3f, sin(t) * 2f); c.scale(sc, sc)
        fill(c, "back_hair", hair); fill(c, "shoulders", 0xFF14182E.toInt()); fill(c, "hood_back", 0xFF0E1226.toInt())
        line(c, "seam_l", accent, 4f); line(c, "seam_r", accent, 4f); fill(c, "neck", 0xFFE3B595.toInt()); line(c, "collar", accent, 5f)
        line(c, "string_l", 0xFFCFD6FF.toInt(), 4f); line(c, "string_r", 0xFFCFD6FF.toInt(), 4f)
        fill(c, "ear_l", 0xFFF0C3A6.toInt()); fill(c, "ear_r", 0xFFF0C3A6.toInt()); fill(c, "face", 0xFFFBD9C2.toInt())
        if (emotion == "love" || emotion == "happy") { p.style = Paint.Style.FILL; p.color = Color.argb(80, 255, 111, 165); c.drawOval(RectF(118f, 254f, 158f, 274f), p); c.drawOval(RectF(242f, 254f, 282f, 274f), p) }
        val big = if (emotion == "surprised") 1.18f else 1f; val gx = sin(t * 0.5f) * 3f; val bl = if ((t % 4.2f) < 0.16f) 0.1f else 1f
        for (m in 0..1) {
            c.save(); if (m == 1) { c.translate(400f, 0f); c.scale(-1f, 1f) }
            c.translate(0f, 219f); c.scale(1f, bl * big); c.translate(0f, -219f)
            fill(c, "sclera_l", Color.WHITE); c.save(); c.clipPath(paths["sclera_l"]!!)
            dot(c, 150f + gx, 219f, 19f, accent); dot(c, 150f + gx, 219f, 12f, Color.argb(90, 0, 0, 0)); dot(c, 150f + gx, 219f, 6.5f, 0xFF0A0A14.toInt())
            dot(c, 143f + gx, 210f, 6f, Color.WHITE); dot(c, 160f + gx, 228f, 3f, Color.WHITE); c.restore()
            line(c, "lash_l", 0xFF12142A.toInt(), 6f); line(c, "flick_l", 0xFF12142A.toInt(), 5f); line(c, "crease_l", 0xFF12142A.toInt(), 2f, 90)
            c.restore()
            c.save(); if (m == 1) { c.translate(400f, 0f); c.scale(-1f, 1f) }
            c.translate(0f, if (emotion == "happy" || emotion == "surprised" || emotion == "love") -5f else 0f)
            c.rotate(when (emotion) { "angry" -> 11f; "sad" -> -11f; else -> 0f }, 150f, 184f); line(c, "brow_l", hair, 6f); c.restore()
        }
        line(c, "nose", 0xFFD9A98A.toInt(), 3f)
        if (emotion == "surprised" || sp) {
            val o = if (emotion == "surprised") 1f else 0.35f + 0.65f * abs(sin(t * 7f))
            c.save(); c.translate(0f, 286f); c.scale(1f, o); c.translate(0f, -286f); fill(c, "mouth_open", 0xFF6E2530.toInt()); fill(c, "tongue", 0xFFD9707A.toInt()); c.restore()
        } else line(c, when (emotion) { "happy", "love" -> "mouth_smile"; "sad", "angry" -> "mouth_sad"; else -> "mouth_neutral" }, 0xFFA8504F.toInt(), 4f)
        if (emotion == "sad") dot(c, 132f, 248f + ((t * 30f) % 1f) * 20f, 4f, 0xFF6EC6FF.toInt())
        fill(c, "side_l", hair); fill(c, "side_r", hair); fill(c, "fringe", hair)
        line(c, "streak1", accent, 5f, 215); line(c, "streak2", accent, 4f, 180); line(c, "streak3", accent, 4f, 180)
        line(c, "band", 0xFF2A3050.toInt(), 11f); line(c, "band", accent, 3f, 230)
        fill(c, "cup_l", 0xFF1F2547.toInt()); fill(c, "cup_r", 0xFF1F2547.toInt()); fill(c, "glow_l", accent); fill(c, "glow_r", accent)
        line(c, "boom", 0xFF2A3050.toInt(), 6f); dot(c, 148f, 326f, 8f, accent)
        c.restore()
    }
}
