package com.jarvis.assistant

import android.content.Intent
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Quick Settings tile: pull down the shade and tap Jarvis to start or stop listening, from any app. */
class JarvisTile : TileService() {
    override fun onStartListening() { refresh() }
    override fun onClick() {
        val i = Intent(this, JarvisService::class.java)
        if (JarvisService.running) stopService(i) else startForegroundService(i)
        qsTile?.state = if (JarvisService.running) Tile.STATE_INACTIVE else Tile.STATE_ACTIVE; qsTile?.updateTile()
    }
    private fun refresh() { qsTile?.state = if (JarvisService.running) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE; qsTile?.updateTile() }
}
