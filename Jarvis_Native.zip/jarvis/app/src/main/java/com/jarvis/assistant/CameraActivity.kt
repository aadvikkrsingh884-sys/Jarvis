package com.jarvis.assistant

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors

/** Live camera vision: a frame every 1.5 s goes to Jarvis, and what he says appears as captions. Ask "what is this?" out loud. */
class CameraActivity : AppCompatActivity() {
    private var front = false
    private lateinit var pv: PreviewView
    private lateinit var cap: TextView
    private val exec = Executors.newSingleThreadExecutor()
    private var last = 0L
    private val rx = object : BroadcastReceiver() { override fun onReceive(c: Context, i: Intent) { cap.text = i.getStringExtra("t")?.trim()?.takeLast(160) ?: "" } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b); front = intent.getBooleanExtra("front", false)
        val fl = FrameLayout(this); pv = PreviewView(this); fl.addView(pv, FrameLayout.LayoutParams(-1, -1))
        cap = TextView(this).apply { setTextColor(-1); textSize = 15f; setBackgroundColor(0x99000000.toInt()); setPadding(24, 16, 24, 16); gravity = Gravity.CENTER }
        fl.addView(cap, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        val bar = LinearLayout(this); bar.orientation = LinearLayout.HORIZONTAL
        bar.addView(Button(this).apply { text = "Flip"; setOnClickListener { front = !front; start() } })
        bar.addView(Button(this).apply { text = "Describe"; setOnClickListener { sendBroadcast(Intent("com.jarvis.SEND_TEXT").setPackage(packageName).putExtra("t", "Describe what you see in the camera in two short sentences.")) } })
        bar.addView(Button(this).apply { text = "Close"; setOnClickListener { finish() } })
        fl.addView(bar, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END))
        if (!JarvisService.running) cap.text = "Press START on the Home screen first, then ask Jarvis what he sees."
        setContentView(fl)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) start()
        else ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 7)
    }
    override fun onRequestPermissionsResult(r: Int, p: Array<out String>, g: IntArray) { super.onRequestPermissionsResult(r, p, g); if (g.firstOrNull() == PackageManager.PERMISSION_GRANTED) start() }

    private fun start() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            val prov = f.get()
            val pre = Preview.Builder().build().also { it.setSurfaceProvider(pv.surfaceProvider) }
            val ia = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            ia.setAnalyzer(exec) { img ->
                val now = System.currentTimeMillis()
                if (now - last > 1500) { last = now
                    try { val bmp = img.toBitmap(); val m = Matrix().apply { postRotate(img.imageInfo.rotationDegrees.toFloat()) }
                        val r = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                        val sc = Bitmap.createScaledBitmap(r, 512, (512f * r.height / r.width).toInt(), true)
                        val o = ByteArrayOutputStream(); sc.compress(Bitmap.CompressFormat.JPEG, 60, o)
                        sendBroadcast(Intent("com.jarvis.FRAME").setPackage(packageName).putExtra("b", o.toByteArray())) } catch (e: Exception) {} }
                img.close() }
            prov.unbindAll()
            prov.bindToLifecycle(this, if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA, pre, ia)
        }, ContextCompat.getMainExecutor(this))
    }
    override fun onStart() { super.onStart(); ContextCompat.registerReceiver(this, rx, IntentFilter("com.jarvis.TEXT"), ContextCompat.RECEIVER_NOT_EXPORTED) }
    override fun onStop() { unregisterReceiver(rx); super.onStop() }
}
