package com.jarvis.assistant

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.*

/** Animated core: slow breathing when idle, tighter ring when listening, fast pulses when speaking. */
class OrbView(ctx: Context) : View(ctx) {
    var accent = 0xFFC9A227.toInt()
    var state = "idle"   // idle | listening | speaking
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = 0f
    override fun onDraw(c: Canvas) {
        t += if (state == "speaking") 0.09f else 0.035f
        val cx = width / 2f; val cy = height / 2f; val base = min(width, height) * 0.30f
        val amp = when (state) { "speaking" -> 0.14f; "listening" -> 0.06f; else -> 0.03f }
        val r = base * (1f + amp * sin(t * 2f))
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy, r * 1.9f, intArrayOf(adj(accent, 0.35f), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r * 1.9f, p); p.shader = null
        p.style = Paint.Style.STROKE; p.color = accent
        p.strokeWidth = 5f; c.drawCircle(cx, cy, r, p)
        p.strokeWidth = 2f; p.alpha = 140; c.drawCircle(cx, cy, r * 0.78f, p); p.alpha = 255
        p.strokeWidth = 7f; p.strokeCap = Paint.Cap.ROUND
        val box = RectF(cx - r * 1.25f, cy - r * 1.25f, cx + r * 1.25f, cy + r * 1.25f)
        for (i in 0 until 4) c.drawArc(box, t * 40f + i * 90f, 38f, false, p)
        p.style = Paint.Style.FILL; p.color = adj(accent, 1.4f); c.drawCircle(cx, cy, r * 0.22f * (1f + amp * sin(t * 4f)), p)
        postInvalidateOnAnimation()
    }
    private fun adj(col: Int, f: Float): Int = if (f < 1f) Color.argb((255 * f).toInt(), Color.red(col), Color.green(col), Color.blue(col))
        else Color.rgb(min(255, (Color.red(col) * f).toInt()), min(255, (Color.green(col) * f).toInt()), min(255, (Color.blue(col) * f).toInt()))
}
