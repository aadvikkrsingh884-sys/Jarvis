package com.jarvis.assistant

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** One-shot Gemini calls (text and image) used by build_website and look_at_screen. */
object Gemini {
    private val http = OkHttpClient.Builder().callTimeout(90, TimeUnit.SECONDS).build()
    fun call(key: String, prompt: String, imgB64: String? = null): String? {
        Llm.store?.let { if (it.provider != "gemini") return Llm.chat(it, prompt, imgB64) }
        val parts = JSONArray().put(JSONObject().put("text", prompt))
        if (imgB64 != null) parts.put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", imgB64)))
        val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", parts)))
        val req = Request.Builder().url("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=$key")
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        return try { http.newCall(req).execute().use { r -> if (!r.isSuccessful) null else
            JSONObject(r.body!!.string()).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text") } }
        catch (e: Exception) { null }
    }
    fun html(key: String, request: String): String? {
        val t = call(key, "Build a complete, beautiful, mobile-friendly single-file website or browser game for this request. Return ONLY the full HTML document (inline CSS and JS, no external files, no explanations, no markdown fences).\nREQUEST: $request") ?: return null
        return t.trim().removePrefix("```html").removePrefix("```").removeSuffix("```").trim()
    }
    fun htmlUpdate(key: String, previous: String, change: String): String? {
        val t = call(key, "Here is a single-file HTML page. Apply this change and return ONLY the full updated HTML document, no explanations, no fences.\nCHANGE: $change\nPAGE:\n$previous") ?: return null
        return t.trim().removePrefix("```html").removePrefix("```").removeSuffix("```").trim()
    }
}
