package com.jarvis.assistant

import android.util.Base64
import okhttp3.*
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * Gemini Live websocket. Reliability features taken from Mira's client: generation counter (stale sockets are ignored),
 * minimum gap between reconnects, capped back-off, session resumption handle + goAway handling, sliding-window context
 * compression and tuned voice-activity detection.
 */
class LiveClient(
    private val store: SecureStore,
    private val role: () -> Role,
    private val onAudio: (ByteArray) -> Unit,
    private val onTurnDone: () -> Unit,
    private val onInterrupted: () -> Unit,
    private val onTool: (id: String, name: String, args: JSONObject) -> Unit,
    private val onStatus: (String) -> Unit,
    private val onText: (Boolean, String) -> Unit = { _, _ -> }
) {
    private companion object { const val MAX_ATTEMPTS = 40; const val MAX_DELAY = 8000L; const val MIN_GAP = 1200L
        const val WS = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent" }
    private val http = OkHttpClient.Builder().pingInterval(20, TimeUnit.SECONDS).readTimeout(0, TimeUnit.SECONDS).build()
    private var ws: WebSocket? = null
    @Volatile private var ready = false
    @Volatile private var wanted = false
    @Volatile private var gen = 0
    @Volatile private var lastClose = 0L
    @Volatile private var resumeHandle: String? = null
    private var attempt = 0

    fun start() { wanted = true; attempt = 0; connect() }
    fun stop() { wanted = false; ready = false; gen++; ws?.close(1000, "bye"); ws = null; resumeHandle = null }
    /** New role/voice/mode needs a fresh session (new system prompt), so the resume handle is dropped. */
    fun restart() { ready = false; gen++; ws?.cancel(); attempt = 0; resumeHandle = null; connect() }
    private fun reconnectKeepingSession() { ready = false; gen++; ws?.cancel(); connect() }
    fun isReady() = ready

    private fun connect() {
        if (!wanted) return
        val key = store.apiKey.trim()
        if (key.isBlank()) { onStatus("Add your Gemini API key in Settings"); return }
        val g = ++gen
        val wait = MIN_GAP - (System.currentTimeMillis() - lastClose)
        if (wait > 0) { Thread { Thread.sleep(wait); if (g == gen && wanted) openSocket(g, key) }.start(); return }
        openSocket(g, key)
    }
    private fun openSocket(g: Int, key: String) {
        onStatus(if (attempt == 0) "Connecting…" else "Reconnecting…")
        ws = http.newWebSocket(Request.Builder().url("$WS?key=" + URLEncoder.encode(key, "UTF-8")).build(), object : WebSocketListener() {
            override fun onOpen(w: WebSocket, r: Response) { if (g == gen) { onStatus("Setting up Jarvis…"); w.send(setup().toString()) } }
            override fun onMessage(w: WebSocket, text: String) { if (g == gen) handle(text) }
            override fun onMessage(w: WebSocket, bytes: ByteString) { if (g == gen) handle(bytes.utf8()) }
            override fun onFailure(w: WebSocket, t: Throwable, r: Response?) {
                if (g != gen) return
                ready = false; lastClose = System.currentTimeMillis()
                val code = r?.code; val body = try { r?.body?.string() ?: "" } catch (e: Exception) { "" }
                val msg = try { JSONObject(body).getJSONObject("error").getString("message") } catch (e: Exception) { body.take(140) }
                when (code) {
                    400 -> { wanted = false; onStatus("Request rejected (400): $msg") }
                    401, 403 -> { wanted = false; onStatus("API key rejected ($code). Check it in Settings.") }
                    404 -> { wanted = false; onStatus("Model not found: ${store.model}") }
                    else -> retry(if (code != null) "Server error $code" else "Connection lost")
                }
            }
            override fun onClosed(w: WebSocket, c: Int, reason: String) { if (g == gen) { ready = false; lastClose = System.currentTimeMillis(); if (wanted) retry("Reconnecting") } }
        })
    }
    private fun retry(msg: String) {
        if (!wanted) return
        attempt++
        if (attempt > MAX_ATTEMPTS) { wanted = false; onStatus("Could not reconnect after $MAX_ATTEMPTS tries. Tap START again."); return }
        val delay = minOf(MAX_DELAY, 700L * (1 shl minOf(attempt, 4)))
        onStatus("$msg – retry in ${delay / 1000}s"); val g = gen
        Thread { Thread.sleep(delay); if (g == gen && wanted) connect() }.start()
    }

    private fun setup(): JSONObject {
        val r = role()
        val setup = JSONObject()
            .put("model", store.model)
            .put("generationConfig", JSONObject().put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", store.voice.ifEmpty { r.voice })))))
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", Roles.systemPrompt(r, store.userName, store.memory, store.autoMood, Modes.extra(store))))))
            .put("tools", ActionExecutor.declarations())
            .put("inputAudioTranscription", JSONObject()).put("outputAudioTranscription", JSONObject())
            .put("realtimeInputConfig", JSONObject().put("automaticActivityDetection", JSONObject().put("disabled", false)
                .put("startOfSpeechSensitivity", "START_SENSITIVITY_HIGH").put("endOfSpeechSensitivity", "END_SENSITIVITY_HIGH")
                .put("prefixPaddingMs", 250).put("silenceDurationMs", 320)))
            .put("sessionResumption", JSONObject().apply { resumeHandle?.let { put("handle", it) } })
            .put("contextWindowCompression", JSONObject().put("slidingWindow", JSONObject()))
        return JSONObject().put("setup", setup)
    }

    private fun handle(raw: String) { try { handle2(raw) } catch (e: Exception) { /* one bad frame must not kill the session */ } }
    private fun handle2(raw: String) {
        val j = JSONObject(raw)
        if (j.has("setupComplete")) { ready = true; attempt = 0; onStatus("Listening · ${role().title}"); return }
        j.optJSONObject("sessionResumptionUpdate")?.let { u -> if (u.optBoolean("resumable", true)) u.optString("newHandle", "").takeIf { it.isNotEmpty() }?.let { resumeHandle = it } }
        if (j.has("goAway") && wanted) { onStatus("Refreshing connection…"); reconnectKeepingSession(); return }
        j.optJSONObject("serverContent")?.let { sc ->
            if (sc.optBoolean("interrupted")) onInterrupted()
            sc.optJSONObject("inputTranscription")?.optString("text")?.let { if (it.isNotBlank()) onText(true, it) }
            sc.optJSONObject("outputTranscription")?.optString("text")?.let { if (it.isNotBlank()) onText(false, it) }
            sc.optJSONObject("modelTurn")?.optJSONArray("parts")?.let { parts ->
                for (i in 0 until parts.length()) parts.getJSONObject(i).optJSONObject("inlineData")?.let { onAudio(Base64.decode(it.getString("data"), Base64.DEFAULT)) } }
            if (sc.optBoolean("turnComplete")) onTurnDone()
        }
        j.optJSONObject("toolCall")?.optJSONArray("functionCalls")?.let { fc ->
            for (i in 0 until fc.length()) { val c = fc.getJSONObject(i); onTool(c.getString("id"), c.getString("name"), c.optJSONObject("args") ?: JSONObject()) } }
    }

    fun sendAudio(pcm16k: ByteArray, len: Int) {
        if (!ready) return
        val b64 = Base64.encodeToString(pcm16k, 0, len, Base64.NO_WRAP)
        ws?.send("""{"realtimeInput":{"audio":{"data":"$b64","mimeType":"audio/pcm;rate=16000"}}}""")
    }
    fun sendToolResult(id: String, name: String, result: String) {
        ws?.send(JSONObject().put("toolResponse", JSONObject().put("functionResponses", JSONArray().put(
            JSONObject().put("id", id).put("name", name).put("response", JSONObject().put("result", result))))).toString())
    }
    fun sendText(t: String) { if (ready) ws?.send(JSONObject().put("realtimeInput", JSONObject().put("text", t)).toString()) }
    fun sendFrame(b64: String) { if (ready) ws?.send("""{"realtimeInput":{"video":{"data":"$b64","mimeType":"image/jpeg"}}}""") }
}
