package com.jarvis.assistant

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Text/vision "brain" for builders, documents and summaries. Works with any OpenAI-compatible provider. */
object Llm {
    data class P(val id: String, val name: String, val base: String, val model: String, val keyUrl: String, val note: String)
    val all = listOf(
        P("gemini", "Google Gemini (free tier)", "https://generativelanguage.googleapis.com/v1beta/openai", "gemini-2.5-flash", "https://aistudio.google.com/apikey", "1 Open the page. 2 Sign in with Google. 3 Tap Create API key. 4 Copy and paste it into the Gemini key box."),
        P("groq", "Groq (free tier, fast)", "https://api.groq.com/openai/v1", "llama-3.3-70b-versatile", "https://console.groq.com/keys", "1 Open the page. 2 Sign up (no card). 3 Create API Key. 4 Copy and paste it here."),
        P("openrouter", "OpenRouter (free :free models)", "https://openrouter.ai/api/v1", "meta-llama/llama-3.3-70b-instruct:free", "https://openrouter.ai/keys", "1 Open the page. 2 Sign up. 3 Create Key. 4 Paste it here. Use a model that ends in :free."),
        P("cerebras", "Cerebras (free tier)", "https://api.cerebras.ai/v1", "llama-3.3-70b", "https://cloud.cerebras.ai/", "1 Open the page. 2 Sign up. 3 Create an API key. 4 Paste it here."),
        P("mistral", "Mistral (free tier)", "https://api.mistral.ai/v1", "mistral-small-latest", "https://console.mistral.ai/api-keys", "1 Open the page. 2 Sign up, pick the free plan. 3 Create a key. 4 Paste it here."),
        P("openai", "OpenAI (paid only)", "https://api.openai.com/v1", "gpt-4o-mini", "https://platform.openai.com/api-keys", "OpenAI has no free text tier. Add billing, then create a secret key.")
    )
    @Volatile var store: SecureStore? = null
    private val http = OkHttpClient.Builder().callTimeout(90, TimeUnit.SECONDS).build()
    fun byId(id: String) = all.firstOrNull { it.id == id } ?: all[0]

    fun chat(s: SecureStore, prompt: String, imgB64: String?): String? {
        val p = byId(s.provider); val key = s.providerKey(p.id); if (key.isBlank()) return null
        val content: Any = if (imgB64 == null) prompt else JSONArray().put(JSONObject().put("type", "text").put("text", prompt))
            .put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$imgB64")))
        val body = JSONObject().put("model", p.model).put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))
        return try { http.newCall(Request.Builder().url(p.base + "/chat/completions").header("Authorization", "Bearer $key")
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()).execute().use { r ->
            if (!r.isSuccessful) null else JSONObject(r.body!!.string()).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content") } }
        catch (e: Exception) { null }
    }

    /** Checks the key by listing models. Returns a plain-English result. */
    fun test(s: SecureStore): String {
        val p = byId(s.provider); val key = s.providerKey(p.id); if (key.isBlank()) return "Paste a key first."
        return try { http.newCall(Request.Builder().url(p.base + "/models").header("Authorization", "Bearer $key").build()).execute().use { r ->
            when { r.isSuccessful -> "Key works for ${p.name}."; r.code == 401 || r.code == 403 -> "Key rejected (${r.code}). Copy it again with no spaces."; r.code == 429 -> "Key is valid but the free limit is used up for now."; else -> "Server answered ${r.code}." } } }
        catch (e: Exception) { "No internet or the service is unreachable." }
    }
}
