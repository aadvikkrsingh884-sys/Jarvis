package com.jarvis.assistant

import android.annotation.SuppressLint
import android.media.*
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.LoudnessEnhancer
import java.util.concurrent.LinkedBlockingQueue
import kotlin.math.abs
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Mic in at 16 kHz, voice out at 24 kHz. Tuned like Mira's pipeline: echo cancel on, noise suppressor off, soft automatic gain
 * (target RMS 3000, max x6), an echo gate that silences quiet audio while Jarvis is talking, loudness boost on playback,
 * and automatic mic restarts. A human-like pause is added before each reply.
 */
class AudioIO(private val onMic: (ByteArray, Int) -> Unit, private val isSpeaking: () -> Boolean = { false }, private val onFatal: (String) -> Unit = {}) {
    private companion object { const val IN_RATE = 16000; const val OUT_RATE = 24000; const val CHUNK = 1024; const val NOISE_FLOOR = 120f; const val TARGET_RMS = 3000f
        const val GAIN_MAX = 6f; const val ECHO_GATE = 700f; const val OUT_GAIN = 1.4f; const val MAX_MIC_RETRIES = 15; const val SLICE = 4800 }
    @Volatile private var running = false
    private val out = LinkedBlockingQueue<ByteArray>()
    @Volatile private var turnStarted = false
    private var track: AudioTrack? = null
    private var gain = 1f
    var pauseMinMs = 1000; var pauseMaxMs = 1500

    @SuppressLint("MissingPermission")
    fun start() {
        running = true
        val tmin = AudioTrack.getMinBufferSize(OUT_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(OUT_RATE).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(maxOf(tmin, OUT_RATE)).setTransferMode(AudioTrack.MODE_STREAM).setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY).build().also { it.play() }
        try { LoudnessEnhancer(track!!.audioSessionId).apply { setTargetGain(600); enabled = true } } catch (e: Exception) {}
        Thread { micLoop() }.start()
        Thread {
            while (running) {
                val chunk = out.take()
                if (chunk.isEmpty()) continue
                if (!turnStarted) { turnStarted = true; Thread.sleep(Random.nextLong(pauseMinMs.toLong(), pauseMaxMs.toLong())) }
                var o = 0
                while (o < chunk.size) { val n = minOf(SLICE, chunk.size - o); track?.write(boost(chunk, o, n), 0, n); o += n }
            }
        }.start()
    }

    private fun boost(b: ByteArray, off: Int, n: Int): ByteArray {
        val r = ByteArray(n); var i = 0
        while (i + 1 < n) { val s = ((b[off + i + 1].toInt() shl 8) or (b[off + i].toInt() and 0xFF)).toShort().toInt(); val v = (s * OUT_GAIN).toInt().coerceIn(-32768, 32767)
            r[i] = (v and 0xFF).toByte(); r[i + 1] = ((v shr 8) and 0xFF).toByte(); i += 2 }
        return r
    }

    @SuppressLint("MissingPermission")
    private fun micLoop() {
        var retries = 0
        while (running) {
            var rec: AudioRecord? = null
            try {
                val min = AudioRecord.getMinBufferSize(IN_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                rec = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, IN_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, CHUNK) * 2)
                if (rec.state != AudioRecord.STATE_INITIALIZED) throw IllegalStateException("Microphone did not start (permission, or another app is using it)")
                try { if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(rec.audioSessionId)?.enabled = true } catch (e: Exception) {}
                rec.startRecording(); retries = 0; val buf = ByteArray(CHUNK)
                while (running) {
                    val n = rec.read(buf, 0, CHUNK, AudioRecord.READ_BLOCKING)
                    if (n < 0) throw IllegalStateException("Microphone read error $n")
                    if (n > 0) { processMic(buf, n); onMic(buf, n) }
                }
            } catch (e: Exception) {
                if (!running) break
                retries++
                if (retries > MAX_MIC_RETRIES) { onFatal("Microphone failed: ${e.message}"); running = false; break }
                try { Thread.sleep(1000) } catch (x: InterruptedException) {}
            } finally { try { rec?.stop() } catch (e: Exception) {}; try { rec?.release() } catch (e: Exception) {} }
        }
    }

    /** Soft AGC + echo gate, in place. */
    private fun processMic(b: ByteArray, n: Int) {
        var sum = 0.0; var i = 0
        while (i + 1 < n) { val s = ((b[i + 1].toInt() shl 8) or (b[i].toInt() and 0xFF)).toShort().toInt(); sum += s.toDouble() * s; i += 2 }
        val rms = sqrt(sum / (n / 2)).toFloat()
        if (isSpeaking() && rms < ECHO_GATE) { java.util.Arrays.fill(b, 0, n, 0); return }
        val target = if (rms > NOISE_FLOOR) (TARGET_RMS / rms).coerceIn(1f, GAIN_MAX) else 1f
        gain += (target - gain) * 0.2f
        if (abs(gain - 1f) < 0.02f) return
        i = 0
        while (i + 1 < n) { val s = ((b[i + 1].toInt() shl 8) or (b[i].toInt() and 0xFF)).toShort().toInt(); val v = (s * gain).toInt().coerceIn(-32768, 32767)
            b[i] = (v and 0xFF).toByte(); b[i + 1] = ((v shr 8) and 0xFF).toByte(); i += 2 }
    }

    fun play(pcm24k: ByteArray) { out.put(pcm24k) }
    fun turnDone() { turnStarted = false }
    fun interrupt() { out.clear(); track?.pause(); track?.flush(); track?.play(); turnStarted = false }
    fun stop() { running = false; out.put(ByteArray(0)); try { track?.release() } catch (e: Exception) {}; track = null }
}
