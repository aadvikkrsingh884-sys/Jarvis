package com.jarvis.assistant

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.StaticLayout
import android.text.TextPaint
import java.io.ByteArrayOutputStream

/** Renders plain text with "# " headings, "## " sub-headings and "- " bullets into a clean multi-page A4 PDF. */
object DocumentPdf {
    fun render(text: String, accent: Int): ByteArray {
        val W = 595; val H = 842; val M = 42f; val width = (W - 2 * M).toInt()
        val doc = PdfDocument(); var n = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(W, H, n).create()); var c: Canvas = page.canvas; var y = M + 10f
        fun bar(cv: Canvas) { cv.drawRect(0f, 0f, W.toFloat(), 14f, Paint().apply { color = accent }) }
        bar(c)
        val body = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF222222.toInt(); textSize = 11f }
        val h1 = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = accent; textSize = 24f; typeface = Typeface.DEFAULT_BOLD }
        val h2 = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = accent; textSize = 13.5f; typeface = Typeface.DEFAULT_BOLD }
        val line = Paint().apply { color = accent; strokeWidth = 1.2f }
        fun newPage() { doc.finishPage(page); n++; page = doc.startPage(PdfDocument.PageInfo.Builder(W, H, n).create()); c = page.canvas; bar(c); y = M + 10f }
        for (raw in text.lines()) {
            val l = raw.trimEnd()
            if (l.isBlank()) { y += 6f; continue }
            val (paint, s, indent, after) = when {
                l.startsWith("# ") -> Quad(h1, l.drop(2), 0f, 8f)
                l.startsWith("## ") -> Quad(h2, l.drop(3).uppercase(), 0f, 4f)
                l.startsWith("- ") || l.startsWith("* ") -> Quad(body, "•  " + l.drop(2), 10f, 3f)
                else -> Quad(body, l, 0f, 4f)
            }
            if (paint === h2) y += 8f
            val layout = StaticLayout.Builder.obtain(s, 0, s.length, paint, width - indent.toInt()).setLineSpacing(2f, 1f).build()
            if (y + layout.height > H - M) newPage()
            c.save(); c.translate(M + indent, y); layout.draw(c); c.restore(); y += layout.height + after
            if (paint === h2) { c.drawLine(M, y, W - M, y, line); y += 5f }
        }
        doc.finishPage(page)
        val out = ByteArrayOutputStream(); doc.writeTo(out); doc.close(); return out.toByteArray()
    }
    private data class Quad(val a: TextPaint, val b: String, val c: Float, val d: Float)
}
