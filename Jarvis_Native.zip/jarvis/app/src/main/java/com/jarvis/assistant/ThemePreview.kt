package com.jarvis.assistant

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.min

/** Small live preview card for the theme grid. */
class ThemePreview(ctx: Context, private val th: Theme, private val selected: Boolean) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); val r = RectF(0f, 0f, w, h)
        p.shader = LinearGradient(0f, 0f, 0f, h, th.bgTop, th.bgBottom, Shader.TileMode.CLAMP); c.drawRoundRect(r, 28f, 28f, p); p.shader = null
        val cx = w / 2; val cy = h / 2; val rad = min(w, h) * 0.28f
        p.style = Paint.Style.STROKE; p.strokeWidth = 6f; p.color = th.accent; c.drawCircle(cx, cy, rad, p)
        p.strokeWidth = 3f; p.color = th.accent2; c.drawCircle(cx, cy, rad * 0.7f, p)
        p.style = Paint.Style.FILL; p.color = th.accent; c.drawCircle(cx, cy, rad * 0.2f, p)
        if (selected) { p.style = Paint.Style.STROKE; p.strokeWidth = 5f; p.color = th.accent; c.drawRoundRect(RectF(3f, 3f, w - 3f, h - 3f), 26f, 26f, p) }
    }
}
