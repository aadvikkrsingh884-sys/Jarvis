package com.jarvis.assistant

import android.app.Service
import android.content.*
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeoutOrNull

/** Floating orb (tap = mute/unmute, long-press = open app, drag = move), live captions, notification cards and the confirmation card. */
class OverlayService : Service() {
    companion object {
        @Volatile var inst: OverlayService? = null
        /** Shows a Yes/No card over any app. False on No, timeout, or when overlay isn't available. */
        suspend fun confirm(msg: String): Boolean {
            val s = inst ?: return false
            val d = CompletableDeferred<Boolean>(); s.main.post { s.showConfirm(msg, d) }
            return withTimeoutOrNull(30000) { d.await() } ?: false
        }
    }
    val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var store: SecureStore
    private lateinit var bubble: LinearLayout
    private lateinit var orb: OrbView
    private lateinit var caption: TextView
    private var accent = 0xFFC9A227.toInt()
    private val hideCaption = Runnable { caption.visibility = View.GONE }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun type() = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    private fun card(): GradientDrawable = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(0xF0101010.toInt()); setStroke(dp(1), accent) }

    private val rx = object : BroadcastReceiver() { override fun onReceive(c: Context, i: Intent) {
        when (i.action) {
            "com.jarvis.STATUS" -> { val s = i.getStringExtra("s") ?: return; orb.state = when { s.startsWith("Speaking") -> "speaking"; s.startsWith("Listening") -> "listening"; else -> "idle" } }
            "com.jarvis.TEXT" -> { val t = i.getStringExtra("t") ?: return; val u = i.getBooleanExtra("u", false)
                caption.text = (if (u) "You: " else "") + t.trim().takeLast(110); caption.visibility = View.VISIBLE; main.removeCallbacks(hideCaption); main.postDelayed(hideCaption, 6000) }
            "com.jarvis.NOTIF" -> if (store.announceNotifs) showNotif(i.getStringExtra("t") ?: "")
        } } }

    override fun onCreate() {
        super.onCreate(); inst = this
        store = SecureStore(this); wm = getSystemService(WINDOW_SERVICE) as WindowManager
        accent = Themes.resolve(store.themeId, Roles.byId(store.roleId)).accent
        orb = OrbView(this).apply { this.accent = this@OverlayService.accent }
        caption = TextView(this).apply { setTextColor(-1); textSize = 12f; setPadding(dp(10), dp(6), dp(10), dp(6)); background = card(); visibility = View.GONE; maxWidth = dp(240) }
        bubble = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        bubble.addView(orb, LinearLayout.LayoutParams(dp(84), dp(84))); bubble.addView(caption)
        val lp = WindowManager.LayoutParams(-2, -2, type(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
            .apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(120) }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false; var down = 0L
        orb.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false; down = System.currentTimeMillis() }
                MotionEvent.ACTION_MOVE -> { if (Math.abs(e.rawX - sx) > 12 || Math.abs(e.rawY - sy) > 12) moved = true
                    if (moved) { lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy + (e.rawY - sy).toInt(); wm.updateViewLayout(bubble, lp) } }
                MotionEvent.ACTION_UP -> if (!moved) { if (System.currentTimeMillis() - down > 600) startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    else sendBroadcast(Intent("com.jarvis.TOGGLE_MUTE").setPackage(packageName)) }
            }; true }
        wm.addView(bubble, lp)
        val f = IntentFilter().apply { addAction("com.jarvis.STATUS"); addAction("com.jarvis.TEXT"); addAction("com.jarvis.NOTIF") }
        ContextCompat.registerReceiver(this, rx, f, ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    private fun overlayLp(top: Boolean) = WindowManager.LayoutParams(-2, -2, type(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
        .apply { gravity = if (top) Gravity.TOP or Gravity.CENTER_HORIZONTAL else Gravity.CENTER; y = if (top) dp(60) else 0 }

    fun showNotif(t: String) {
        val v = TextView(this).apply { text = "🔔 $t"; setTextColor(-1); textSize = 13f; setPadding(dp(14), dp(10), dp(14), dp(10)); background = card(); maxWidth = dp(320) }
        wm.addView(v, overlayLp(true)); main.postDelayed({ try { wm.removeView(v) } catch (e: Exception) {} }, 5000)
    }

    fun showConfirm(msg: String, d: CompletableDeferred<Boolean>) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(16), dp(18), dp(14)); background = card() }
        box.addView(TextView(this).apply { text = "Jarvis asks"; setTextColor(accent); textSize = 11f })
        box.addView(TextView(this).apply { text = msg; setTextColor(-1); textSize = 16f; setPadding(0, dp(6), 0, dp(12)); maxWidth = dp(300) })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun done(v: Boolean) { try { wm.removeView(box) } catch (e: Exception) {}; d.complete(v) }
        fun b(t: String, v: Boolean) = Button(this).apply { text = t; setTextColor(if (v) 0xFF000000.toInt() else accent); background = GradientDrawable().apply { cornerRadius = dp(8).toFloat(); setColor(if (v) accent else 0x00000000); setStroke(dp(1), accent) }; setOnClickListener { done(v) } }
        row.addView(b("No", false), LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(8) }); row.addView(b("Yes", true), LinearLayout.LayoutParams(0, -2, 1f))
        box.addView(row)
        wm.addView(box, WindowManager.LayoutParams(-2, -2, type(), WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.CENTER })
    }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onDestroy() { inst = null; try { unregisterReceiver(rx); wm.removeView(bubble) } catch (e: Exception) {}; super.onDestroy() }
}
