package com.jarvis.assistant

import android.content.Context
import android.content.Intent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Website / game builder and PDF documents. Used by voice tools and by the Create tab. */
object Creator {
    suspend fun website(ctx: Context, key: String, request: String, update: Boolean): String {
        val h = withContext(Dispatchers.IO) { if (update && WebActivity.html.isNotBlank()) Gemini.htmlUpdate(key, WebActivity.html, request) else Gemini.html(key, request) }
        if (h.isNullOrBlank()) return "error: could not generate the page (check API key / internet)"
        WebActivity.html = h; WebActivity.name = request.take(24).replace(Regex("[^A-Za-z0-9]+"), "_").trim('_').ifEmpty { "site" }
        ctx.startActivity(Intent(ctx, WebActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "ok: built and opened (${h.length} chars). Buttons on top save it as ZIP/HTML or share it."
    }

    suspend fun document(ctx: Context, key: String, type: String, details: String, accent: Int): String {
        val guide = when (type.lowercase()) {
            "resume", "cv" -> "a modern professional resume: name line, contact line, summary, experience, education, skills, projects"
            "biodata" -> "a clean biodata (marriage/personal profile): personal details, family, education, occupation, interests, contact"
            "letter" -> "a formal letter with date, address block, subject, body and sign-off"
            else -> "a well structured $type"
        }
        val t = withContext(Dispatchers.IO) { Gemini.call(key, "Write $guide.\nOutput plain text only. First line '# Full Title or Name'. Section headings start with '## '. Bullets start with '- '. No markdown bold, no tables. Do NOT invent personal facts (phone, address, employers); where details are missing use [placeholders].\nUSER DETAILS: $details") }
        if (t.isNullOrBlank()) return "error: could not write the document (check API key / internet)"
        val pdf = withContext(Dispatchers.Default) { DocumentPdf.render(t.replace("**", ""), accent) }
        val uri = Files.save(ctx, "${type}_${System.currentTimeMillis() / 1000}.pdf", "application/pdf", pdf) ?: return "error: could not save the PDF"
        ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/pdf").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
        return "ok: PDF saved in Downloads/Jarvis and opened"
    }
}
