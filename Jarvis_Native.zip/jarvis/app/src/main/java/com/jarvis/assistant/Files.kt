package com.jarvis.assistant

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object Files {
    /** Saves into Downloads/Jarvis (no storage permission needed on Android 10+). */
    fun save(ctx: Context, name: String, mime: String, bytes: ByteArray): Uri? = try {
        val v = ContentValues().apply { put(MediaStore.MediaColumns.DISPLAY_NAME, name); put(MediaStore.MediaColumns.MIME_TYPE, mime); put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/Jarvis") }
        val u = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
        if (u != null) ctx.contentResolver.openOutputStream(u)?.use { it.write(bytes) }
        u
    } catch (e: Exception) { null }

    fun zip(files: Map<String, String>): ByteArray {
        val o = ByteArrayOutputStream()
        ZipOutputStream(o).use { z -> files.forEach { (n, c) -> z.putNextEntry(ZipEntry(n)); z.write(c.toByteArray()); z.closeEntry() } }
        return o.toByteArray()
    }
}
