package com.jarvis.assistant

data class Theme(val id: String, val name: String, val bgTop: Int, val bgBottom: Int, val accent: Int, val accent2: Int, val mode: String) {
    val light: Boolean get() = id == "light"
}

object Themes {
    private fun t(id: String, n: String, a: Long, b: Long, c: Long, d: Long, m: String) = Theme(id, n, a.toInt(), b.toInt(), c.toInt(), d.toInt(), m)
    val all = listOf(
        t("auto", "Follow Role", 0xFF050505, 0xFF0A0A0A, 0xFFC9A227, 0xFFFFFFFF, "aurora"),
        t("iron", "Iron Gold", 0xFF000000, 0xFF1A1608, 0xFFC9A227, 0xFFE8C766, "grid"),
        t("cyber", "Cyber Tech", 0xFF02060E, 0xFF0A1F33, 0xFF00E5FF, 0xFF7C4DFF, "grid"),
        t("matrix", "Matrix", 0xFF000000, 0xFF001A06, 0xFF00FF41, 0xFF00B82E, "matrix"),
        t("neon", "Neon Future", 0xFF0A0014, 0xFF1A0033, 0xFFFF2BD6, 0xFF00E5FF, "aurora"),
        t("luxury", "Dark Luxury", 0xFF0B0B0B, 0xFF1C1712, 0xFFD4AF37, 0xFF8B6B23, "plain"),
        t("midnight", "Midnight Blue", 0xFF050B1F, 0xFF0B1E4A, 0xFF4F8CFF, 0xFF8FB8FF, "aurora"),
        t("anime", "Anime Gaming", 0xFF0D0221, 0xFF2A0A5E, 0xFFB388FF, 0xFFFF4FD8, "aurora"),
        t("ocean", "Ocean", 0xFF021A24, 0xFF04485E, 0xFF21D4FD, 0xFF2AF598, "aurora"),
        t("sunset", "Sunset", 0xFF1A0510, 0xFF4A1A12, 0xFFFF7A3D, 0xFFFF3D6E, "aurora"),
        t("carbon", "Carbon Red", 0xFF0A0A0A, 0xFF1A0505, 0xFFFF1744, 0xFFFF8A80, "grid"),
        t("aurora", "Aurora", 0xFF04121A, 0xFF0A2A2A, 0xFF5CFFB5, 0xFF7C9CFF, "aurora"),
        t("stealth", "Stealth Minimal", 0xFF0D0D0D, 0xFF151515, 0xFFE0E0E0, 0xFF9E9E9E, "plain"),
        t("forest", "Forest", 0xFF06150A, 0xFF0F2E17, 0xFF6BFF8A, 0xFFB6FF6B, "aurora"),
        t("glass", "Glassmorphism", 0xFF0E1424, 0xFF1B2A4A, 0xFF9CC9FF, 0xFFB388FF, "aurora"),
        t("purple", "Purple Fantasy", 0xFF120626, 0xFF2B0F55, 0xFFB26BFF, 0xFFFF6BD6, "aurora"),
        t("light", "Light Mode", 0xFFF6F3EE, 0xFFE8E2D8, 0xFF6A4AFF, 0xFFB05A2A, "plain"),
        t("rose", "Rose", 0xFF1A0A12, 0xFF3A1226, 0xFFFF6FA5, 0xFFFFB3D1, "aurora")
    )
    fun byId(id: String) = all.firstOrNull { it.id == id } ?: all[1]
    /** "Follow Role" builds a theme from the active role's colours. */
    fun resolve(id: String, role: Role): Theme =
        if (id == "auto") Theme("auto", "Follow Role", role.bg, role.bg, role.accent, role.accent, "aurora") else byId(id)
}
