package com.jarvis.assistant

import java.util.concurrent.CopyOnWriteArrayList

/** In-memory conversation log (never written to disk). */
object Chat {
    val log = CopyOnWriteArrayList<Pair<Boolean, String>>()   // (fromUser, text)
    fun save(store: SecureStore) { try { val a = org.json.JSONArray(); log.takeLast(60).forEach { a.put(org.json.JSONArray().put(it.first).put(it.second)) }; store.chatJson = a.toString() } catch (e: Exception) {} }
    fun load(store: SecureStore) { try { val a = org.json.JSONArray(store.chatJson); log.clear(); for (i in 0 until a.length()) log.add(a.getJSONArray(i).getBoolean(0) to a.getJSONArray(i).getString(1)) } catch (e: Exception) {} }
    fun recent(store: SecureStore, n: Int = 8): String = try { val a = org.json.JSONArray(store.chatJson); (maxOf(0, a.length() - n) until a.length()).joinToString("\n") { (if (a.getJSONArray(it).getBoolean(0)) "User: " else "Jarvis: ") + a.getJSONArray(it).getString(1).take(160) } } catch (e: Exception) { "" }
    fun add(user: Boolean, t: String) {
        if (t.isBlank()) return
        val last = log.lastOrNull()
        if (last != null && last.first == user) log[log.size - 1] = user to (last.second + t) else log.add(user to t)
        while (log.size > 80) log.removeAt(0)
    }
}

/** Keyword mood guess for the avatar face (English + Hinglish). */
object EmotionReader {
    private val map = mapOf(
        "happy" to listOf("haha", "great", "awesome", "nice", "congrat", "mast", "badhiya", "khush", "yay", "wow", "bahut accha", "shandar", "love it"),
        "sad" to listOf("sad", "sorry", "dukh", "udaas", "rona", "cry", "alone", "akela", "miss", "bura laga", "hurt", "tension"),
        "angry" to listOf("angry", "gussa", "hate", "idiot", "stupid", "bakwas", "chup", "shut up", "irritat", "pagal"),
        "love" to listOf("love you", "pyaar", "pyar", "jaan", "baby", "dear", "sweetheart", "miss you", "dil"),
        "surprised" to listOf("really", "sach", "kya baat", "no way", "seriously", "omg", "arre")
    )
    fun guess(text: String): String {
        val t = text.lowercase()
        return map.maxByOrNull { (_, ws) -> ws.count { t.contains(it) } }?.takeIf { (_, ws) -> ws.any { t.contains(it) } }?.key ?: "neutral"
    }
}
