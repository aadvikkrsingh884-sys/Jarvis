package com.jarvis.assistant

import android.content.Context
import android.graphics.Path
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.math.abs

/**
 * Minecraft (Bedrock, touch controls) mission player.
 * 1) opens the game and enters the last world, 2) learns where the on-screen controls are (calibration from a screenshot),
 * 3) loops: screenshot -> vision model decides up to 3 control macros + reads health/hunger/threat -> macros are performed with real
 * multi-finger gestures (joystick + mining at the same time) -> a safety supervisor can retreat or stop the mission.
 * Tell the game: Settings > Show Coordinates ON, and keep a pickaxe, food and torches in the hotbar.
 */
class MinecraftAgent(private val ctx: Context, private val store: SecureStore, private val enterWorld: suspend () -> String) {
    @Volatile private var cancelled = false
    fun cancel() { cancelled = true }
    private val http = OkHttpClient.Builder().callTimeout(45, TimeUnit.SECONDS).build()
    private val MC = "com.mojang.minecraftpe"

    /** Normalised (0..1) positions of the touch controls. Defaults match the classic layout; calibration overwrites them. */
    private class Layout { var joyX = .14f; var joyY = .78f; var jumpX = .87f; var jumpY = .72f; var sneakX = .79f; var sneakY = .84f; var invX = .93f; var invY = .10f
        var slot1X = .30f; var slot9X = .70f; var slotY = .93f; var crossX = .5f; var crossY = .5f }

    private fun ask(prompt: String, img: String): JSONObject? = try {
        val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt))
            .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", img))))))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json").put("temperature", 0.2))
        http.newCall(Request.Builder().url("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=${store.apiKey.trim()}")
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()).execute().use { r ->
            if (!r.isSuccessful) null else {
                val t = JSONObject(r.body!!.string()).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
                JSONObject(t.trim().removePrefix("```json").removeSuffix("```").trim()) } }
    } catch (e: Exception) { null }

    private fun pt(o: JSONObject?, k: String): Pair<Float, Float>? {
        val a = o?.optJSONArray(k) ?: return null; if (a.length() < 2) return null
        var x = a.optDouble(0).toFloat(); var y = a.optDouble(1).toFloat(); if (x > 1f || y > 1f) { x /= 1000f; y /= 1000f }
        return if (x in 0f..1f && y in 0f..1f) Pair(x, y) else null
    }
    private suspend fun calibrate(svc: JarvisAccessibilityService, L: Layout) {
        val shot = svc.screenshotWithSig() ?: return
        val j = ask("This is a Minecraft Bedrock Edition screenshot with touch controls. Return ONE JSON object with the centre of each control as [x,y] in 0..1 (0,0 top-left), or null if not visible: " +
            "{\"joystick\":[x,y],\"jump\":[x,y],\"sneak\":[x,y],\"inventory\":[x,y],\"hotbar_slot_1\":[x,y],\"hotbar_slot_9\":[x,y],\"crosshair\":[x,y]}", shot.first) ?: return
        pt(j, "joystick")?.let { L.joyX = it.first; L.joyY = it.second }; pt(j, "jump")?.let { L.jumpX = it.first; L.jumpY = it.second }; pt(j, "sneak")?.let { L.sneakX = it.first; L.sneakY = it.second }
        pt(j, "inventory")?.let { L.invX = it.first; L.invY = it.second }; pt(j, "crosshair")?.let { L.crossX = it.first; L.crossY = it.second }
        pt(j, "hotbar_slot_1")?.let { L.slot1X = it.first; L.slotY = it.second }; pt(j, "hotbar_slot_9")?.let { L.slot9X = it.first }
    }

    // ----- control macros (real multi-touch) -----
    private fun hold(x: Float, y: Float) = Path().apply { moveTo(x, y); lineTo(x + 1f, y) }
    private fun joystick(L: Layout, W: Float, H: Float, dir: String): Path {
        val cx = L.joyX * W; val cy = L.joyY * H; val r = 0.085f * H
        val (tx, ty) = when (dir) { "back" -> Pair(cx, cy + r); "left" -> Pair(cx - r, cy); "right" -> Pair(cx + r, cy); else -> Pair(cx, cy - r) }
        val horizontalDir = dir == "left" || dir == "right"
        return Path().apply { moveTo(cx, cy); lineTo(tx, ty)
            repeat(34) { i -> val o = if (i % 2 == 0) 5f else -5f; if (horizontalDir) lineTo(tx, ty + o) else lineTo(tx + o, ty) } }   // keeps the stick deflected for most of the time
    }
    private suspend fun macro(svc: JarvisAccessibilityService, L: Layout, W: Float, H: Float, a: JSONObject): String {
        val ms = a.optLong("ms", 800).coerceIn(150, 5000); val cross = Pair(L.crossX * W, L.crossY * H)
        return when (a.optString("a")) {
            "walk" -> if (svc.multiPaths(listOf(joystick(L, W, H, a.optString("dir", "forward"))), ms)) "ok" else "gesture failed"
            "walk_mine" -> if (svc.multiPaths(listOf(joystick(L, W, H, a.optString("dir", "forward")), hold(cross.first, cross.second)), ms)) "ok" else "gesture failed"
            "mine" -> if (svc.multiPaths(listOf(hold(cross.first, cross.second)), ms)) "ok" else "gesture failed"
            "place" -> if (svc.tap(cross.first, cross.second)) "ok" else "gesture failed"
            "look" -> { val dx = a.optDouble("dx", 0.0).toFloat().coerceIn(-1.5f, 1.5f); val dy = a.optDouble("dy", 0.0).toFloat().coerceIn(-1.5f, 1.5f)
                val sx = 0.68f * W; val sy = 0.40f * H; if (svc.swipe(sx, sy, sx + dx * 0.30f * W, sy + dy * 0.30f * H, 320)) "ok" else "gesture failed" }
            "jump" -> if (svc.multiPaths(listOf(hold(L.jumpX * W, L.jumpY * H)), 140)) "ok" else "gesture failed"
            "sneak" -> if (svc.tap(L.sneakX * W, L.sneakY * H)) "ok" else "gesture failed"
            "slot" -> { val n = a.optInt("n", 1).coerceIn(1, 9); if (svc.tap((L.slot1X + (L.slot9X - L.slot1X) * (n - 1) / 8f) * W, L.slotY * H)) "ok" else "gesture failed" }
            "eat" -> { if (a.has("n")) macro(svc, L, W, H, JSONObject().put("a", "slot").put("n", a.optInt("n", 1))); if (svc.multiPaths(listOf(hold(cross.first, cross.second)), 2200)) "ok" else "gesture failed" }
            "inventory" -> if (svc.tap(L.invX * W, L.invY * H)) "ok" else "gesture failed"
            "close" -> svc.press("back")
            "wait" -> { delay(ms); "ok" }
            else -> "unknown action"
        }
    }

    suspend fun run(goal: String, report: (String) -> Unit): String {
        val svc = JarvisAccessibilityService.inst ?: return "error: Accessibility is OFF"
        if (store.apiKey.isBlank()) return "error: a Gemini key is needed for the Minecraft agent (Settings)"
        cancelled = false
        val g = goal.lowercase()
        val target: Int? = Regex("(\\d+)\\s*stacks?").find(g)?.groupValues?.get(1)?.toIntOrNull()?.times(64) ?: Regex("(\\d+)\\s*diamonds?").find(g)?.groupValues?.get(1)?.toIntOrNull()
        report("Opening Minecraft")
        val phone = Phone(ctx, store)
        if (svc.currentPackage() != MC) { val o = withContext(Dispatchers.IO) { phone.openApp("minecraft") }; if (o.startsWith("error")) return o; withContext(Dispatchers.IO) { svc.waitForPackage(MC, 15000) } }
        if (svc.currentPackage() != MC) return "error: Minecraft did not open"
        delay(2500)
        val ent = enterWorld(); if (cancelled) return "stopped by user"
        if (ent.startsWith("error")) report("Could not confirm that I'm inside a world: $ent")
        val L = Layout(); calibrate(svc, L); report("Controls found. Starting the mission")
        val dm = ctx.resources.displayMetrics; var W = dm.widthPixels.toFloat(); var H = dm.heightPixels.toFloat()
        if (W < H) { val t = W; W = H; H = t }   // Minecraft runs in landscape
        val log = ArrayDeque<String>(); var prev: IntArray? = null; var still = 0; var retreats = 0; var lastObs = ""; var lowHp = 0
        for (step in 1..600) {
            if (cancelled) return "stopped by user after ${step - 1} steps. $lastObs"
            if (svc.currentPackage() != MC) { if (withContext(Dispatchers.IO) { phone.openApp("minecraft") }.startsWith("error")) return "error: left Minecraft and could not return"; delay(4000) }
            val shot = svc.screenshotWithSig() ?: return "error: screenshot failed (Android 11+ is needed, or the screen is off)"
            val diff = prev?.let { p -> shot.second.indices.sumOf { abs(shot.second[it] - p[it]) } / 64 } ?: 99; prev = shot.second
            still = if (diff < 2) still + 1 else 0
            if (still >= 8) return "error: the game picture stopped changing (frozen or paused). $lastObs"
            val j = ask(prompt(goal, target, log.joinToString("\n"), still), shot.first) ?: run { delay(1500); null } ?: continue
            val obs = j.optJSONObject("obs"); val hearts = obs?.opt("hearts")?.let { (it as? Number)?.toInt() }; val threat = obs?.optString("threat", "none") ?: "none"
            val count = obs?.opt("item_count")?.let { (it as? Number)?.toInt() }
            lastObs = "hearts=${hearts ?: "?"} hunger=${obs?.opt("hunger") ?: "?"} y=${obs?.opt("y") ?: "?"} items=${count ?: "?"} threat=$threat"
            if (target != null && count != null && count >= target) return "mission complete: $count collected (target $target)"
            lowHp = if (hearts != null && hearts <= 3) lowHp + 1 else 0
            if (lowHp >= 2) return "stopped to stay alive: health is critical. $lastObs"
            var acts = j.optJSONArray("actions") ?: JSONArray()
            if (threat == "lava" || threat == "void" || threat == "fall") {
                retreats++; if (retreats >= 3) return "stopped: repeated danger ($threat). $lastObs"
                acts = JSONArray().put(JSONObject().put("a", "walk").put("dir", "back").put("ms", 700)); log.addLast("SUPERVISOR: retreated from $threat")
            } else retreats = 0
            var note = j.optString("say", "")
            for (i in 0 until minOf(acts.length(), 3)) {
                if (cancelled) break
                val a = acts.optJSONObject(i) ?: continue
                when (a.optString("a")) { "done" -> return "ok: ${a.optString("result", "finished")}. $lastObs"; "abort" -> return "stopped: ${a.optString("reason", "unsafe")}. $lastObs" }
                val r = macro(svc, L, W, H, a); log.addLast("${step}.${i + 1} ${a.toString().take(70)} -> $r"); if (log.size > 8) log.removeFirst()
                delay(120)
            }
            if (step % 8 == 0) report("Step $step: $lastObs. $note")
        }
        return "reached the step limit. $lastObs"
    }

    private fun prompt(goal: String, target: Int?, history: String, still: Int) = """
You are the brain of an autonomous player in Minecraft Bedrock Edition on a phone (touch controls, landscape). MISSION: $goal${if (target != null) " (target item count: $target)" else ""}.
You see one screenshot. Reply with ONE JSON object only:
{"obs":{"hearts":0-10 or null,"hunger":0-10 or null,"y":integer or null (from the coordinates on screen),"item_count":integer or null (how many of the target item are in the inventory/hotbar),"threat":"none|lava|water|void|fall|mob|dark","ahead":"what is in front"},"say":"one short note","actions":[up to 3 of the actions below]}
Actions: {"a":"look","dx":-1..1,"dy":-1..1} (right/down positive, 1 is about 90 degrees) | {"a":"walk","dir":"forward|back|left|right","ms":300-3000} | {"a":"mine","ms":500-4000} (hold on the crosshair: breaks the block in front) | {"a":"walk_mine","dir":"forward","ms":500-3000} (walk and mine together) | {"a":"place"} (tap: place the selected block/use item) | {"a":"jump"} | {"a":"sneak"} | {"a":"slot","n":1-9} | {"a":"eat","n":1-9} | {"a":"inventory"} | {"a":"close"} | {"a":"wait","ms":500} | {"a":"done","result":"..."} | {"a":"abort","reason":"..."}
SAFETY FIRST (never die): never dig straight down or straight up, dig a 2-high staircase at about 45 degrees; before walking check for lava, water and drops; if lava or water is next to the path, place a block in it or turn away; if a mob is close, fight only with a weapon selected, otherwise retreat and block the tunnel behind you; eat when hunger is 6 or lower; if hearts are 4 or lower stop mining and retreat. Put torches behind you in dark tunnels.
DIAMONDS: they are most common at Y -58 to -59. Dig a staircase down to about Y -58 (watch the Y coordinate), then branch-mine in straight 2-high tunnels, looking at the walls: white-cyan dots mean diamond ore. Collect it with an iron or better pickaxe. Count the diamonds in the inventory.
If the game shows a menu, dialog or death screen, press the right button or use {"a":"abort"}. ${if (still >= 3) "The picture has not changed for $still steps: try something different." else ""}
RECENT ACTIONS:
$history""".trimIndent()
}
