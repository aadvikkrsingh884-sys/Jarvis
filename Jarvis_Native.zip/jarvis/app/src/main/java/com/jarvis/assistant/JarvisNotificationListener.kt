package com.jarvis.assistant

import android.app.Notification
import android.content.Intent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Message notifications (WhatsApp, Telegram, SMS and other messaging apps). Follows Mira's filtering: only messaging apps or
 * category "msg", group summaries and "N new messages" noise are skipped, and the same text is never reported twice.
 * Nothing is written to disk.
 */
class JarvisNotificationListener : NotificationListenerService() {
    companion object {
        val recent = java.util.concurrent.ConcurrentLinkedDeque<String>()
        private val MESSAGING = setOf("com.whatsapp", "com.whatsapp.w4b", "org.telegram.messenger", "org.telegram.messenger.web", "com.google.android.apps.messaging", "com.samsung.android.messaging",
            "com.android.mms", "com.facebook.orca", "com.instagram.android", "com.snapchat.android", "com.discord", "com.microsoft.teams", "com.Slack", "com.google.android.gm")
        private val NOISE = Regex("(\\d+\\s+(new\\s+)?messages?)|checking for new messages|web is currently active|backup in progress", RegexOption.IGNORE_CASE)
    }
    private val last = HashMap<String, String>()

    override fun onNotificationPosted(sbn: StatusBarNotification?) { try { if (sbn != null) handle(sbn) } catch (t: Throwable) {} }
    private fun handle(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification ?: return
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        if (n.category != Notification.CATEGORY_MESSAGE && sbn.packageName !in MESSAGING) return
        val e = n.extras ?: return
        var sender = e.getCharSequence("android.title")?.toString() ?: ""
        var text = (e.getCharSequence("android.bigText") ?: e.getCharSequence("android.text"))?.toString() ?: ""
        @Suppress("DEPRECATION") val msgs = e.getParcelableArray("android.messages")
        (msgs?.lastOrNull() as? android.os.Bundle)?.let { b -> b.getCharSequence("text")?.toString()?.takeIf { it.isNotBlank() }?.let { text = it }; b.getCharSequence("sender")?.toString()?.takeIf { it.isNotBlank() }?.let { sender = it } }
        if (text.isBlank() || sender.isBlank() || NOISE.containsMatchIn(text) || NOISE.containsMatchIn(sender)) return
        val sig = "$sender|$text"
        synchronized(last) { if (last[sbn.key] == sig) return; if (last.size > 100) last.clear(); last[sbn.key] = sig }
        val app = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString() } catch (x: Exception) { sbn.packageName }
        val line = "$app: $sender – $text".take(220); recent.addFirst(line); while (recent.size > 15) recent.removeLast()
        sendBroadcast(Intent("com.jarvis.NOTIF").setPackage(packageName).putExtra("t", line).putExtra("app", app).putExtra("sender", sender).putExtra("text", text))
    }
}
