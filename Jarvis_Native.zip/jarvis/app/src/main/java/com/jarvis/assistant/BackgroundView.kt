package com.jarvis.assistant

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.*
import kotlin.random.Random

/** Animated backdrop per theme: aurora blobs, cyber grid with scan line, matrix rain, or plain gradient. */
class BackgroundView(ctx: Context) : View(ctx) {
    var theme: Theme = Themes.all[1]; set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = 0f
    private val drops = FloatArray(60) { Random.nextFloat() * 2000f }
    private val chars = "01<>/{}=+*#".toCharArray()
    override fun onDraw(c: Canvas) {
        t += 0.012f; val w = width.toFloat(); val h = height.toFloat()
        p.shader = LinearGradient(0f, 0f, 0f, h, theme.bgTop, theme.bgBottom, Shader.TileMode.CLAMP); p.style = Paint.Style.FILL
        c.drawRect(0f, 0f, w, h, p); p.shader = null
        when (theme.mode) {
            "aurora" -> for (i in 0..2) {
                val cx = w * (0.5f + 0.4f * sin(t * (0.6f + i * 0.25f) + i * 2f)); val cy = h * (0.3f + 0.25f * cos(t * (0.5f + i * 0.2f) + i))
                val col = if (i % 2 == 0) theme.accent else theme.accent2
                p.shader = RadialGradient(cx, cy, w * 0.75f, Color.argb(70, Color.red(col), Color.green(col), Color.blue(col)), Color.TRANSPARENT, Shader.TileMode.CLAMP)
                c.drawCircle(cx, cy, w * 0.75f, p); p.shader = null
            }
            "grid" -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = 1f; p.color = Color.argb(28, Color.red(theme.accent), Color.green(theme.accent), Color.blue(theme.accent))
                val g = 64f; var x = 0f; while (x < w) { c.drawLine(x, 0f, x, h, p); x += g }
                var y = (t * 40f) % g; while (y < h) { c.drawLine(0f, y, w, y, p); y += g }
                p.strokeWidth = 3f; p.color = Color.argb(50, Color.red(theme.accent), Color.green(theme.accent), Color.blue(theme.accent))
                val sy = (t * 260f) % h; c.drawLine(0f, sy, w, sy, p)
            }
            "matrix" -> {
                p.style = Paint.Style.FILL; p.textSize = 30f; p.typeface = Typeface.MONOSPACE
                val cols = (w / 30f).toInt()
                for (i in 0 until cols) {
                    val head = (drops[i % 60] + t * 320f * (0.5f + (i % 5) * 0.2f)) % (h + 300f)
                    for (k in 0 until 9) { val y = head - k * 32f; if (y < 0 || y > h) continue
                        p.color = Color.argb(max(0, 200 - k * 24), Color.red(theme.accent), Color.green(theme.accent), Color.blue(theme.accent))
                        c.drawText(chars[(i * 7 + k + (t * 6).toInt()) % chars.size].toString(), i * 30f, y, p) }
                }
            }
        }
        postInvalidateOnAnimation()
    }
}
