package com.jarvis.assistant

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.webkit.WebView
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast

/** Preview of what Jarvis built, with ZIP / HTML export and share. */
class WebActivity : Activity() {
    companion object { @Volatile var html: String = ""; @Volatile var name: String = "site" }
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(0xFF111111.toInt()) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; isAllCaps = false; setOnClickListener { f() } }.also { bar.addView(it, LinearLayout.LayoutParams(0, -2, 1f)) }
        btn("Save ZIP") { toast(Files.save(this, "$name.zip", "application/zip", Files.zip(mapOf("index.html" to html, "README.txt" to "Built with Jarvis. Open index.html in any browser.")))?.let { "Saved in Downloads/Jarvis" } ?: "Save failed") }
        btn("Save HTML") { toast(Files.save(this, "$name.html", "text/html", html.toByteArray())?.let { "Saved in Downloads/Jarvis" } ?: "Save failed") }
        btn("Share") { val u = Files.save(this, "$name.zip", "application/zip", Files.zip(mapOf("index.html" to html)))
            if (u != null) startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("application/zip").putExtra(Intent.EXTRA_STREAM, u).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Share")) }
        btn("Close") { finish() }
        val w = WebView(this); w.settings.javaScriptEnabled = true; w.settings.domStorageEnabled = true
        w.loadDataWithBaseURL(null, html, "text/html", "utf-8", null)
        root.addView(bar, LinearLayout.LayoutParams(-1, -2)); root.addView(w, LinearLayout.LayoutParams(-1, 0, 1f)); setContentView(root)
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
