package com.jarvis.assistant

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlin.math.*

/**
 * Basic owner-voice check. It builds a 24-band voice-shape profile and compares it while you talk.
 * Sensitive tools (unlock, call, SMS, WhatsApp, social posts, app tasks) run only if your voice matched within the last 6 s.
 * This is a lightweight check: it will not stop a high-quality recording or clone. Keep Android's own screen lock on.
 */
class VoiceLock(private val store: SecureStore) {
    companion object {
        @Volatile var inst: VoiceLock? = null
        private const val THR = 0.88
        private val centers = DoubleArray(24) { 150.0 * (3800.0 / 150.0).pow(it / 23.0) }
        fun features(s: ShortArray, n: Int): DoubleArray? {
            var e = 0.0; for (i in 0 until n) e += s[i].toDouble().pow(2)
            if (sqrt(e / n) < 500) return null
            val v = DoubleArray(24)
            for ((k, f) in centers.withIndex()) {
                val c = 2 * cos(2 * PI * f / 16000); var s1 = 0.0; var s2 = 0.0
                for (i in 0 until n) { val x = s[i] * (0.5 - 0.5 * cos(2 * PI * i / (n - 1))); val s0 = x + c * s1 - s2; s2 = s1; s1 = s0 }
                v[k] = ln(s1 * s1 + s2 * s2 - c * s1 * s2 + 1.0)
            }
            return norm(v)
        }
        fun norm(v: DoubleArray): DoubleArray { val m = v.average(); val sd = sqrt(v.sumOf { (it - m).pow(2) } / v.size) + 1e-9; return DoubleArray(v.size) { (v[it] - m) / sd } }
        fun corr(a: DoubleArray, b: DoubleArray) = a.indices.sumOf { a[it] * b[it] } / a.size
    }
    private var ref: DoubleArray? = store.voiceprint.split(",").mapNotNull { it.toDoubleOrNull() }.takeIf { it.size == 24 }?.toDoubleArray()
    private val recent = ArrayDeque<DoubleArray>()
    @Volatile private var lastMatch = 0L
    @Volatile var lastScore = 0.0

    fun enabled() = store.requireVoiceLock && ref != null
    fun ownerRecently() = !enabled() || System.currentTimeMillis() - lastMatch < 6000

    /** Called for every mic chunk. Never blocks audio; only updates the match score. */
    fun accept(pcm: ByteArray, len: Int): Boolean {
        val r = ref ?: return true
        val n = len / 2; if (n < 512) return true
        val s = ShortArray(512) { ((pcm[2 * it + 1].toInt() shl 8) or (pcm[2 * it].toInt() and 0xFF)).toShort() }
        val f = features(s, 512) ?: return true
        recent.addLast(f); if (recent.size > 20) recent.removeFirst()
        if (recent.size >= 5) {
            val avg = DoubleArray(24) { k -> recent.sumOf { it[k] } / recent.size }
            lastScore = corr(norm(avg), r); if (lastScore >= THR) lastMatch = System.currentTimeMillis()
        }
        return true
    }

    /** Records [seconds] seconds of your normal speech and saves the profile (encrypted). Stop Jarvis first. */
    @SuppressLint("MissingPermission")
    fun enroll(seconds: Int, done: (Boolean) -> Unit) = Thread {
        try {
            val min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val rec = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, 16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, min * 2)
            rec.startRecording(); val buf = ShortArray(512); val acc = ArrayList<DoubleArray>(); val end = System.currentTimeMillis() + seconds * 1000L
            while (System.currentTimeMillis() < end) { val n = rec.read(buf, 0, 512); if (n == 512) features(buf, 512)?.let { acc.add(it) } }
            rec.stop(); rec.release()
            if (acc.size < 25) { done(false); return@Thread }
            val avg = norm(DoubleArray(24) { k -> acc.sumOf { it[k] } / acc.size })
            store.voiceprint = avg.joinToString(","); ref = avg; done(true)
        } catch (e: Exception) { done(false) }
    }.start()
}
