package com.jarvis.assistant

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** Everything private lives here: AES-256 encrypted, never backed up, never sent anywhere except what you allow. */
class SecureStore(ctx: Context) {
    private val sp: SharedPreferences = EncryptedSharedPreferences.create(
        ctx, "jarvis_secure",
        MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
    var apiKey: String get() = sp.getString("key", "") ?: "" ; set(v) = sp.edit().putString("key", v).apply()
    var model: String get() = sp.getString("model", "models/gemini-3.8-live") ?: "" ; set(v) = sp.edit().putString("model", v).apply()
    var userName: String get() = sp.getString("name", "Friend") ?: "Friend" ; set(v) = sp.edit().putString("name", v).apply()
    var roleId: String get() = sp.getString("role", "jarvis") ?: "jarvis" ; set(v) = sp.edit().putString("role", v).apply()
    var customRoles: String get() = sp.getString("custom", "") ?: "" ; set(v) = sp.edit().putString("custom", v).apply()
    /** Unlock pattern as dot numbers 1..9, e.g. "14753". Stored encrypted only. */
    var pattern: String get() = sp.getString("pattern", "") ?: "" ; set(v) = sp.edit().putString("pattern", v).apply()
    var gridX: Float get() = sp.getFloat("gx", 0.5f) ; set(v) = sp.edit().putFloat("gx", v).apply()
    var gridY: Float get() = sp.getFloat("gy", 0.68f) ; set(v) = sp.edit().putFloat("gy", v).apply()
    var gridSize: Float get() = sp.getFloat("gs", 0.38f) ; set(v) = sp.edit().putFloat("gs", v).apply()
    var voiceprint: String get() = sp.getString("vp", "") ?: "" ; set(v) = sp.edit().putString("vp", v).apply()
    var requireVoiceLock: Boolean get() = sp.getBoolean("vlock", false) ; set(v) = sp.edit().putBoolean("vlock", v).apply()
    var memory: String get() = sp.getString("mem", "") ?: "" ; set(v) = sp.edit().putString("mem", v.takeLast(6000)).apply()
    var autoMood: Boolean get() = sp.getBoolean("auto", true) ; set(v) = sp.edit().putBoolean("auto", v).apply()
    var themeId: String get() = sp.getString("theme", "iron") ?: "iron" ; set(v) = sp.edit().putString("theme", v).apply()
    var avatarStyle: String get() = sp.getString("avatar", "face") ?: "face" ; set(v) = sp.edit().putString("avatar", v).apply()
    var overlay: Boolean get() = sp.getBoolean("overlay", true) ; set(v) = sp.edit().putBoolean("overlay", v).apply()
    var announceNotifs: Boolean get() = sp.getBoolean("announce", false) ; set(v) = sp.edit().putBoolean("announce", v).apply()
    /** reply pause in tenths of a second: min = v/10 s, max = min + 0.5 s */
    var pauseTenths: Int get() = sp.getInt("pause", 10) ; set(v) = sp.edit().putInt("pause", v).apply()
    var voice: String get() = sp.getString("voice", "") ?: "" ; set(v) = sp.edit().putString("voice", v).apply()
    var emoStyle: String get() = sp.getString("emo", "Warm") ?: "Warm" ; set(v) = sp.edit().putString("emo", v).apply()
    var mode: String get() = sp.getString("mode", "") ?: "" ; set(v) = sp.edit().putString("mode", v).apply()
    var saveChat: Boolean get() = sp.getBoolean("savechat", true) ; set(v) = sp.edit().putBoolean("savechat", v).apply()
    var chatJson: String get() = sp.getString("chat", "[]") ?: "[]" ; set(v) = sp.edit().putString("chat", v).apply()
    var accounts: String get() = sp.getString("accts", "{}") ?: "{}" ; set(v) = sp.edit().putString("accts", v).apply()
    var journal: String get() = sp.getString("journal", "") ?: "" ; set(v) = sp.edit().putString("journal", v.takeLast(20000)).apply()
    var framing: String get() = sp.getString("framing", "full") ?: "full" ; set(v) = sp.edit().putString("framing", v).apply()
    var cutBg: Boolean get() = sp.getBoolean("cutbg", true) ; set(v) = sp.edit().putBoolean("cutbg", v).apply()
    var provider: String get() = sp.getString("prov", "gemini") ?: "gemini" ; set(v) = sp.edit().putString("prov", v).apply()
    fun providerKey(id: String): String = if (id == "gemini") apiKey else (sp.getString("pk_$id", "") ?: "")
    fun setProviderKey(id: String, k: String) { if (id == "gemini") apiKey = k else sp.edit().putString("pk_$id", k).apply() }
    var patternSpeed: Int get() = sp.getInt("pspeed", 900) ; set(v) = sp.edit().putInt("pspeed", v).apply()
    fun remember(line: String) { memory = memory + "\n- " + line }
    fun wipe() = sp.edit().clear().apply()
}
