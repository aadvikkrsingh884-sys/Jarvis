package com.jarvis.assistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.ContactsContract
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.BatteryManager
import android.provider.AlarmClock
import android.view.KeyEvent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/** Tools Gemini can call. Every result is a plain string the model must report honestly. */
class ActionExecutor(private val ctx: Context, private val store: SecureStore, private val onEvent: (String) -> Unit = {}, private val onSwitchRole: (String) -> Unit = {}) {
    private val agent by lazy { AgentLoop(ctx, store) { this } }
    private var pendingConfirm: String? = null

    companion object {
        fun declarations(): JSONArray {
            fun f(name: String, desc: String, vararg params: String) = JSONObject().put("name", name).put("description", desc).apply {
                if (params.isNotEmpty()) put("parameters", JSONObject().put("type", "OBJECT").put("properties",
                    JSONObject().apply { params.forEach { put(it, JSONObject().put("type", "STRING")) } }).put("required", JSONArray(params.toList())))
            }
            return JSONArray().put(JSONObject().put("functionDeclarations", JSONArray()
                .put(f("unlock_phone", "Wake the phone and draw the saved unlock pattern"))
                .put(f("open_app", "Open an installed app by its name", "app_name"))
                .put(f("call_contact", "Call a saved contact by name", "name"))
                .put(f("press_system_button", "back, home, recents, notifications, quick_settings, lock_screen, screenshot", "button"))
                .put(f("describe_screen", "Read visible text and buttons on screen"))
                .put(f("tap_element", "Tap the on-screen element with this label", "label"))
                .put(f("type_text", "Type text into the focused field", "text"))
                .put(f("remember", "Save a fact about the user for future chats", "fact"))
                .put(f("close_app", "Close the app currently on screen"))
                .put(f("flashlight", "Turn the flashlight on or off", "state"))
                .put(f("volume", "Control media volume: action is up, down, mute, unmute or set (set needs percent 0-100, else pass 0)", "action", "percent"))
                .put(f("lock_phone", "Lock the phone screen"))
                .put(f("toggle_setting", "Turn a quick setting on or off, e.g. Wi-Fi, Bluetooth, Mobile data, Flashlight, Airplane mode", "label", "state"))
                .put(f("install_app", "Install an app from the Play Store", "app_name"))
                .put(f("uninstall_app", "Uninstall an app", "app_name"))
                .put(f("whatsapp_send_media", "Send the latest photo or video to a WhatsApp contact. type is photo or video; which is latest, first, screenshot or camera", "contact", "type", "which"))
                .put(f("whatsapp_status", "Put the latest photo or video on WhatsApp Status", "type", "which"))
                .put(f("post_story", "Post the latest photo or video to an Instagram or Facebook story. platform is instagram or facebook", "platform", "type", "which"))
                .put(f("read_screen", "Read the text on the current screen"))
                .put(f("click_on_screen", "Tap the on-screen item with this text", "text"))
                .put(f("scroll_screen", "Scroll the current screen up or down", "direction"))
                .put(f("media_key", "play_pause, next or previous for music/video", "key"))
                .put(f("open_url", "Open a website link", "url"))
                .put(f("set_alarm", "Set an alarm at a 24-hour time", "hour", "minute"))
                .put(f("set_timer", "Start a countdown timer", "seconds"))
                .put(f("send_sms", "Open a text message ready to send to a contact or number", "to", "text"))
                .put(f("battery_info", "Battery percentage"))
                .put(f("look_at_screen", "Look at the current screen and answer a question about it", "question"))
                .put(f("read_notifications", "Read the latest phone notifications"))
                .put(f("play_youtube", "Search and play something on YouTube", "query"))
                .put(f("navigate", "Start navigation or search a place in Maps", "place"))
                .put(f("play_store", "Search an app in Play Store", "app_name"))
                .put(f("whatsapp_send", "Open a WhatsApp chat with the message filled in", "to", "text"))
                .put(f("open_settings", "Open a settings page: wifi, bluetooth, display, sound, battery, apps, location, airplane, nfc, accessibility", "page"))
                .put(f("web_search", "Search the web in the browser", "query"))
                .put(f("build_website", "Build a website, web page or browser game and show it", "request"))
                .put(f("update_website", "Change the website you just built", "change"))
                .put(f("make_document", "Make a PDF: resume, biodata, letter or report", "type", "details"))
                .put(f("see_through_camera", "Open live camera vision, camera is front or back", "camera"))
                .put(f("share_text", "Open the share sheet with text", "text"))
                .put(f("create_folder", "Create a folder in Documents/Jarvis", "name"))
                .put(f("create_file", "Create a text file in Documents/Jarvis", "name", "content"))
                .put(f("social_post", "Post a story, post or reel on instagram, facebook or whatsapp. kind is story, post or reel", "platform", "kind", "caption"))
                .put(f("open_saved_account", "Open a saved account: YouTube, Instagram, Facebook or Telegram", "name"))
                .put(f("analyze_saved_accounts", "Read the user's saved public profile links and summarise them"))
                .put(f("journal_add", "Save a journal entry", "text"))
                .put(f("journal_read", "Read back recent journal entries"))
                .put(f("set_mode", "Switch mode: music, study, journal or none", "mode"))
                .put(f("do_task", "Do a multi-step task in any app by looking at the screen (ChatGPT, Gemini, WhatsApp, YouTube, settings...)", "goal"))
                .put(f("play_game", "Play a game for the user, e.g. mine diamonds in Minecraft", "goal"))
                .put(f("stop_task", "Stop the current do_task or play_game immediately"))
                .put(f("switch_role", "Change personality role to match the user's mood: jarvis, girlfriend, bigbro, smallbro, sister, friend, mentor, listener", "role_id"))
                .put(f("confirm_action", "Confirm a sensitive action after the user clearly said yes", "token"))))
        }
    }

    @Volatile private var pending: String? = null
    @Volatile private var approved: String? = null
    @Volatile var socialApproved = false

    /** Confirmation card over any app (or auto-yes during an approved social post). */
    suspend fun confirm(msg: String): Boolean = socialApproved || OverlayService.confirm(msg)

    /** Entry point for every tool call: risky ones go through the confirmation card first. */
    private val phone by lazy { Phone(ctx, store) }
    private val social by lazy { Social(ctx, store, phone) }
    private val gameScope = kotlinx.coroutines.CoroutineScope(Dispatchers.Default + kotlinx.coroutines.SupervisorJob())
    private var gameJob: kotlinx.coroutines.Job? = null
    private val mc by lazy { MinecraftAgent(ctx, store) { agent.run("Make sure Minecraft is in a world: if on the main menu tap Play and open the most recent world; if a loading screen shows, wait. Finish (done) when the in-game screen with the hotbar and crosshair is visible.", false, 25) } }
    fun cancelAll() { agent.cancel(); mc.cancel(); gameJob?.cancel() }
    private fun startGame(goal: String): String {
        val g = goal.lowercase()
        if (!g.contains("minecraft") && !g.contains("diamond") && !g.contains("mine ") && !g.contains("stack")) return "GENERIC"
        if (gameJob?.isActive == true) return "error: a Minecraft mission is already running. Say stop first."
        gameJob = gameScope.launch {
            val r = try { mc.run(goal) { onEvent("PHONE EVENT (automatic): Minecraft progress: $it. Tell the user in one short sentence.") } } catch (e: Exception) { "error: ${e.message}" }
            onEvent("PHONE EVENT (automatic): the Minecraft mission ended: $r. Tell the user in one or two short sentences.")
        }
        return "ok: Minecraft mission started. I will report progress. Say stop, or use the Stop button in the notification, to cancel."
    }
    /** Tools that use the step-by-step phone flows (run off the main thread because they wait for the screen). */
    private suspend fun viaPhone(name: String, a: JSONObject): String? = withContext(Dispatchers.IO) { when (name) {
        "unlock_phone" -> phone.unlock()
        "lock_phone" -> phone.lock()
        "open_app" -> phone.openApp(a.optString("app_name"))
        "call_contact" -> phone.call(a.optString("number"), a.optString("name"), true)
        "send_sms" -> phone.composeSms(a.optString("number"), a.optString("text"), a.optString("to").ifEmpty { a.optString("name") }, a.optString("send") != "false")
        "whatsapp_send" -> phone.sendWhatsApp(a.optString("to"), a.optString("text"))
        "play_youtube" -> phone.playYouTube(a.optString("query"))
        "press_system_button" -> JarvisAccessibilityService.inst?.press(a.optString("button")) ?: "error: Accessibility is OFF"
        "open_settings" -> phone.openSettings(a.optString("page"))
        "set_alarm" -> phone.setAlarm(a.optString("hour").toIntOrNull() ?: 7, a.optString("minute").toIntOrNull() ?: 0, a.optString("label"))
        "set_timer" -> phone.setTimer(a.optString("seconds").toIntOrNull() ?: 60, a.optString("label"))
        "set_volume", "volume" -> phone.volume(a.optString("action", "set"), a.optString("percent").toIntOrNull())
        "read_screen", "describe_screen" -> phone.readScreen()
        "click_on_screen", "tap_element" -> phone.clickOnScreen(a.optString("text").ifEmpty { a.optString("label") })
        "scroll_screen" -> phone.scroll(a.optString("direction", "down"))
        "type_text" -> phone.type(a.optString("text"))
        "toggle_setting" -> phone.toggleSetting(a.optString("label"), a.optString("state").lowercase() in listOf("on", "true", "1", "enable"))
        "install_app" -> phone.installApp(a.optString("app_name"))
        "uninstall_app" -> phone.uninstallApp(a.optString("app_name"))
        "whatsapp_send_media" -> social.whatsappSendMedia(a.optString("contact"), a.optString("type", "photo"), a.optString("which", "latest"), 1)
        "whatsapp_status" -> social.whatsappStatusMedia(a.optString("type", "photo"), a.optString("which", "latest"), 1)
        "post_story" -> social.postStory(a.optString("platform"), a.optString("type", "photo"), a.optString("which", "latest"), 1)
        else -> null } }

    suspend fun run(name: String, a: JSONObject): String {
        if (name in setOf("unlock_phone", "call_contact", "send_sms", "whatsapp_send", "social_post", "do_task", "play_game", "install_app", "uninstall_app", "whatsapp_send_media", "whatsapp_status", "post_story", "toggle_setting") && VoiceLock.inst?.ownerRecently() == false)
            return "error: the voice did not match the owner. Ask the user to repeat it, or turn off 'Only my voice' in Settings."
        val ask = when (name) {
            "call_contact" -> "Call ${a.optString("name")}?"
            "send_sms" -> "Open a text message to ${a.optString("to")}?"
            "whatsapp_send" -> "Open WhatsApp chat with ${a.optString("to")} and fill your message?"
            "social_post" -> "Post a ${a.optString("kind", "story")} on ${a.optString("platform")} now?"
            "play_store" -> "Open Play Store for ${a.optString("app_name")}?"
            "install_app" -> "Install ${a.optString("app_name")} from the Play Store?"
            "uninstall_app" -> "Uninstall ${a.optString("app_name")}?"
            "whatsapp_send_media" -> "Send a ${a.optString("type", "photo")} to ${a.optString("contact")} on WhatsApp?"
            "whatsapp_status" -> "Put a ${a.optString("type", "photo")} on your WhatsApp status?"
            "post_story" -> "Post a ${a.optString("type", "photo")} to your ${a.optString("platform")} story?"
            else -> null
        }
        if (ask != null) {
            val key = name + a.toString()
            if (approved == key) approved = null
            else if (OverlayService.inst != null) { if (!OverlayService.confirm(ask)) return "error: user said no" }
            else { pending = key; return "CONFIRMATION_REQUIRED: ask the user out loud: $ask Then call confirm_action and repeat the same call." }
        }
        return viaPhone(name, a) ?: exec(name, a)
    }

    private suspend fun exec(name: String, a: JSONObject): String {
        val svc = JarvisAccessibilityService.inst
        return try { when (name) {
            "unlock_phone" -> phone.unlock()
            "open_app" -> openApp(a.optString("app_name"))
            "call_contact" -> call(a.optString("name"))
            "press_system_button" -> svc?.press(a.optString("button")) ?: "error: Accessibility is OFF"
            "describe_screen" -> svc?.describeScreen() ?: "error: Accessibility is OFF"
            "tap_element" -> svc?.tapText(a.optString("label")) ?: "error: Accessibility is OFF"
            "type_text" -> svc?.typeText(a.optString("text")) ?: "error: Accessibility is OFF"
            "remember" -> { store.remember(a.optString("fact")); "ok" }
            "close_app" -> svc?.closeCurrentApp() ?: "error: Accessibility is OFF"
            "flashlight" -> torch(a.optString("state").lowercase() in listOf("on", "true", "1"))
            "set_volume" -> { val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                val v = (am.getStreamMaxVolume(AudioManager.STREAM_MUSIC) * a.optString("percent").toIntOrNull().let { (it ?: 50).coerceIn(0, 100) } / 100)
                am.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0); "ok" }
            "media_key" -> { val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                val code = when (a.optString("key")) { "next" -> KeyEvent.KEYCODE_MEDIA_NEXT; "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS; else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE }
                am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code)); am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code)); "ok" }
            "open_url" -> { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(a.optString("url"))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "ok" }
            "set_alarm" -> { ctx.startActivity(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, a.optString("hour").toInt())
                .putExtra(AlarmClock.EXTRA_MINUTES, a.optString("minute").toInt()).putExtra(AlarmClock.EXTRA_SKIP_UI, true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "ok: alarm set" }
            "set_timer" -> { ctx.startActivity(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, a.optString("seconds").toInt())
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "ok: timer started" }
            "send_sms" -> { val to = a.optString("to"); val num = if (to.any { it.isLetter() }) lookup(to) else to
                if (num == null) "error: contact '$to' not found" else {
                ctx.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$num")).putExtra("sms_body", a.optString("text")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                "ok: message opened, not sent yet; use do_task to press Send if the user asked to send" } }
            "battery_info" -> "ok: " + (ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) + "%"
            "look_at_screen" -> agent.look(a.optString("question"))
            "read_notifications" -> JarvisNotificationListener.recent.take(8).joinToString("\n").ifBlank { "ok: no notifications captured (is Notification access enabled for Jarvis?)" }
            "play_youtube" -> go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(a.optString("query")))), "ok: YouTube results opened; call do_task to tap the first video if the user wants it played")
            "navigate" -> go(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(a.optString("place")))), "ok: Maps opened")
            "play_store" -> go(Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=" + Uri.encode(a.optString("app_name")))), "ok: Play Store search opened; call do_task to install (installs need a clear yes)")
            "web_search" -> go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(a.optString("query")))), "ok")
            "whatsapp_send" -> { val to = a.optString("to"); val raw = if (to.any { it.isLetter() }) lookup(to) else to
                val d = raw?.filter { it.isDigit() }?.let { if (it.length == 10) "91$it" else it }
                if (d.isNullOrBlank()) "error: contact '$to' not found" else go(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$d?text=" + Uri.encode(a.optString("text")))), "ok: chat opened with text filled, NOT sent yet; call do_task to press Send") }
            "open_settings" -> go(Intent(when (a.optString("page").lowercase()) {
                "wifi" -> android.provider.Settings.ACTION_WIFI_SETTINGS; "bluetooth" -> android.provider.Settings.ACTION_BLUETOOTH_SETTINGS
                "display" -> android.provider.Settings.ACTION_DISPLAY_SETTINGS; "sound" -> android.provider.Settings.ACTION_SOUND_SETTINGS
                "battery" -> android.provider.Settings.ACTION_BATTERY_SAVER_SETTINGS; "apps" -> android.provider.Settings.ACTION_APPLICATION_SETTINGS
                "location" -> android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS; "airplane" -> android.provider.Settings.ACTION_AIRPLANE_MODE_SETTINGS
                "nfc" -> android.provider.Settings.ACTION_NFC_SETTINGS; "accessibility" -> android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS
                else -> android.provider.Settings.ACTION_SETTINGS }), "ok: opened; use do_task to flip the switch")
            "build_website" -> Creator.website(ctx, store.apiKey, a.optString("request"), false)
            "update_website" -> Creator.website(ctx, store.apiKey, a.optString("change"), true)
            "make_document" -> Creator.document(ctx, store.apiKey, a.optString("type"), a.optString("details"), Themes.resolve(store.themeId, Roles.byId(store.roleId)).accent)
            "see_through_camera" -> go(Intent(ctx, CameraActivity::class.java).putExtra("front", a.optString("camera").startsWith("front", true)), "ok: camera vision opened; describe what the user asks about from the live frames")
            "share_text" -> go(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, a.optString("text")), "Share"), "ok: share sheet opened")
            "create_folder" -> mk(a.optString("name"), null)
            "create_file" -> mk(a.optString("name"), a.optString("content"))
            "social_post" -> {
                val pf = a.optString("platform"); val kind = a.optString("kind", "story").lowercase(); val cap = a.optString("caption")
                socialApproved = true
                try { agent.run("Open the $pf app. Create a $kind using the latest photo or video (unless the user chose another). " + (if (cap.isNotBlank()) "Caption/text: $cap. " else "") +
                    "STRICT: use only the $kind composer. If a different composer (Story vs Post vs Reel) opens, do not use it; fail instead. If a subscription, paywall or verification screen appears, fail. After the final Share/Post/Your story press, confirm on screen it was published, then done. Never claim success without seeing it.", false, 45) }
                finally { socialApproved = false } }
            "open_saved_account" -> { val u = Accounts.url(a.optString("name"), Accounts.load(store)[a.optString("name").lowercase()] ?: "")
                if (u == null) "error: no saved link for '${a.optString("name")}' (add it in Settings > Saved accounts)" else go(Intent(Intent.ACTION_VIEW, Uri.parse(u)), "ok: opened") }
            "analyze_saved_accounts" -> Accounts.analyze(store)
            "journal_add" -> { store.journal = store.journal + "\n[" + java.text.SimpleDateFormat("d MMM yyyy HH:mm", java.util.Locale.getDefault()).format(java.util.Date()) + "] " + a.optString("text"); "ok: saved" }
            "journal_read" -> store.journal.takeLast(1500).ifBlank { "ok: the journal is empty" }
            "set_mode" -> { onSwitchRole("mode:" + a.optString("mode").lowercase().let { if (it == "none") "" else it }); "ok" }
            "do_task" -> agent.run(a.optString("goal"), false)
            "play_game" -> startGame(a.optString("goal")).let { if (it == "GENERIC") agent.run(a.optString("goal"), true) else it }
            "stop_task" -> { cancelAll(); "ok: stopping" }
            "switch_role" -> { onSwitchRole(a.optString("role_id")); "ok" }
            "confirm_action" -> { approved = pending; "ok" }
            else -> "error: unknown tool"
        } } catch (e: Exception) { "error: ${e.message}" }
    }

    private fun openApp(label: String): String {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val hit = pm.queryIntentActivities(intent, 0).firstOrNull { it.loadLabel(pm).toString().equals(label, true) }
            ?: pm.queryIntentActivities(intent, 0).firstOrNull { it.loadLabel(pm).toString().contains(label, true) }
            ?: return "error: app '$label' not installed"
        val launch = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return "error: cannot launch"
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(launch); return "ok"
    }

    private fun call(name: String): String {
        val c = ctx.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?", arrayOf("%$name%"), null)
        val num = c?.use { if (it.moveToFirst()) it.getString(0) else null } ?: return "error: contact '$name' not found"
        val i = Intent(Intent.ACTION_CALL, Uri.parse("tel:$num")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i); return "ok: calling $name"
    }

    private fun torch(on: Boolean): String {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true } ?: return "error: no flashlight"
        cm.setTorchMode(id, on); return "ok"
    }
    private fun lookup(name: String): String? {
        val c = ctx.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?", arrayOf("%$name%"), null)
        return c?.use { if (it.moveToFirst()) it.getString(0) else null }
    }

    private fun go(i: Intent, ok: String): String = if (phone.launch(i)) ok else "error: could not open it"

    private fun mk(name: String, content: String?): String {
        if (!android.os.Environment.isExternalStorageManager()) return "error: allow 'All files access' for Jarvis in Settings > Apps > Jarvis"
        val dir = java.io.File(android.os.Environment.getExternalStorageDirectory(), "Documents/Jarvis").apply { mkdirs() }
        val f = java.io.File(dir, name.replace("/", "_"))
        return try { if (content == null) { if (f.mkdirs() || f.isDirectory) "ok: folder ${f.path}" else "error: could not create folder" } else { f.writeText(content); "ok: file ${f.path}" } }
        catch (e: Exception) { "error: ${e.message}" }
    }
}
