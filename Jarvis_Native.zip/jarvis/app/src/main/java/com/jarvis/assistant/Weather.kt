package com.jarvis.assistant

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

/** Current temperature and sky from Open-Meteo (free, no key). Uses the last known coarse location; nothing is stored. */
object Weather {
    private val http = OkHttpClient()
    suspend fun get(ctx: Context): Pair<String, String>? = withContext(Dispatchers.IO) {
        try {
            if (ctx.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return@withContext null
            val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val loc = lm.getProviders(true).mapNotNull { lm.getLastKnownLocation(it) }.maxByOrNull { it.time } ?: return@withContext null
            val url = "https://api.open-meteo.com/v1/forecast?latitude=${loc.latitude}&longitude=${loc.longitude}&current=temperature_2m,weather_code"
            http.newCall(Request.Builder().url(url).build()).execute().use { r ->
                val cur = JSONObject(r.body!!.string()).getJSONObject("current")
                val code = cur.getInt("weather_code")
                val sky = when (code) { 0 -> "Clear"; 1, 2, 3 -> "Partly cloudy"; 45, 48 -> "Fog"; in 51..57 -> "Drizzle"; in 61..67 -> "Rain"; in 71..77 -> "Snow"; in 80..82 -> "Showers"; else -> if (code >= 95) "Thunderstorm" else "Cloudy" }
                Math.round(cur.getDouble("temperature_2m")).toString() + "°" to sky
            }
        } catch (e: Exception) { null }
    }
}
