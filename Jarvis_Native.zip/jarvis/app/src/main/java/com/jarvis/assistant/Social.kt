package com.jarvis.assistant

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

/**
 * Sending photos/videos on WhatsApp, WhatsApp Status, and Instagram/Facebook stories. The step logic follows Mira's flows:
 * share intent -> wait for the app -> pick the contact or "My status" -> press Send/Share until it is accepted, with a paywall guard
 * (never presses subscribe/verified/upgrade screens), error detection and loop protection. Call from a background thread.
 */
class Social(private val ctx: Context, private val store: SecureStore, private val phone: Phone) {
    data class Media(val uri: Uri, val mime: String, val name: String, val video: Boolean)
    private fun svc() = JarvisAccessibilityService.inst
    private val noA11y = "error: Accessibility is OFF. Settings > Accessibility > Jarvis > turn it on."
    private fun norm(s: String) = s.lowercase(Locale.ROOT).filter { it.isLetterOrDigit() }
    private fun labelsOf(n: AccessibilityNodeInfo) = listOfNotNull(n.text?.toString(), n.contentDescription?.toString(), n.hintText?.toString()).map { it.trim() }.filter { it.isNotEmpty() }

    // ---------------- media ----------------
    fun hasMediaPermission(video: Boolean): Boolean {
        val p = if (Build.VERSION.SDK_INT >= 33) (if (video) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_MEDIA_IMAGES) else Manifest.permission.READ_EXTERNAL_STORAGE
        return ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    }
    /** which: latest / first / screenshot / camera. nth is 1-based. */
    fun findMedia(video: Boolean, which: String, nth: Int): Media? {
        val base = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val w = which.lowercase(); val where = when { w.contains("screenshot") -> "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?"; w.contains("camera") -> "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?"; else -> null }
        val arg = when { w.contains("screenshot") -> "%Screenshot%"; w.contains("camera") -> "%Camera%"; else -> null }
        val order = if (w.contains("first") || w.contains("oldest")) "${MediaStore.MediaColumns.DATE_ADDED} ASC" else "${MediaStore.MediaColumns.DATE_ADDED} DESC"
        ctx.contentResolver.query(base, arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.MIME_TYPE, MediaStore.MediaColumns.DISPLAY_NAME), where, arg?.let { arrayOf(it) }, order)?.use { c ->
            var i = 0
            while (c.moveToNext()) { i++; if (i >= nth.coerceAtLeast(1)) return Media(ContentUris.withAppendedId(base, c.getLong(0)), c.getString(1) ?: if (video) "video/*" else "image/*", c.getString(2) ?: "", video) }
        }
        return null
    }
    private fun waPackage() = listOf("com.whatsapp", "com.whatsapp.w4b").firstOrNull { phone.installed(it) }
    private fun grant(pkg: String, m: Media) { try { ctx.grantUriPermission(pkg, m.uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) {} }
    private fun shareIntent(m: Media, pkg: String) = Intent(Intent.ACTION_SEND).setType(m.mime).putExtra(Intent.EXTRA_STREAM, m.uri).setPackage(pkg).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)

    // ---------------- WhatsApp: media to a contact, or to Status ----------------
    fun whatsappSendMedia(contact: String, type: String, which: String, nth: Int): String = whatsappShare(contact.trim(), type, which, nth)
    fun whatsappStatusMedia(type: String, which: String, nth: Int): String = whatsappShare(null, type, which, nth)
    private fun whatsappShare(contact: String?, type: String, which: String, nth: Int): String {
        if (contact != null && contact.isEmpty()) return "error: contact name is empty"
        val video = type.lowercase().contains("video"); val wa = waPackage() ?: return "error: WhatsApp is not installed"
        val s = svc() ?: return noA11y
        if (!hasMediaPermission(video)) return "error: Photos/media permission is needed. Allow it in the app permissions and ask again."
        val m = findMedia(video, which, nth) ?: return "error: no ${if (video) "video" else "photo"} found on the phone (${which}, #$nth)"
        grant(wa, m)
        if (!phone.launch(shareIntent(m, wa))) return "error: the WhatsApp share screen did not open"
        if (!s.waitForPackage(wa, 9000)) return "error: WhatsApp did not come to the screen"
        Thread.sleep(1000)
        if (contact != null) pickContact(s, wa, contact)?.let { return it }
        else {
            val labels = listOf("my status", "status (contacts)", "your status", "status")
            val n = s.waitFor(7000) { labels.firstNotNullOfOrNull { l -> s.findByText(l, wa) } } ?: return "error: 'My status' was not found in the WhatsApp share list (WhatsApp version differs). The photo is open on the share screen, so you can choose Status yourself."
            if (!s.click(n)) return "error: could not select My status"
        }
        return pressSend(s, wa, contact)
    }
    private fun pickContact(s: JarvisAccessibilityService, wa: String, contact: String): String? {
        var box = s.findEditable(wa)
        if (box == null) { s.findByText("Search", wa)?.let { s.click(it) }; box = s.waitFor(3000) { s.findEditable(wa) } }
        if (box == null) return "error: the contact search box was not found"
        if (!s.setText(box, contact)) return "error: could not type the contact name"
        Thread.sleep(1300)
        val q = norm(contact)
        val hits = s.waitFor(5000) { s.findNodes(wa) { n -> !n.isEditable && labelsOf(n).any { norm(it).let { x -> x.isNotEmpty() && x.contains(q) } } }.takeIf { it.isNotEmpty() }?.firstOrNull() }
            ?: return "error: no WhatsApp chat or contact named '$contact'"
        val all = s.findNodes(wa) { n -> !n.isEditable && labelsOf(n).any { norm(it).contains(q) } }
        val distinct = all.flatMap { n -> labelsOf(n).filter { norm(it).contains(q) } }.map { it.trim() }.distinct()
        val exact = all.firstOrNull { n -> labelsOf(n).any { norm(it) == q } }
        if (exact == null && distinct.size > 1) return "error: several contacts match: ${distinct.take(5).joinToString(", ")}. Ask the user which one."
        return if (s.click(exact ?: hits)) null else "error: could not select '$contact'"
    }
    private fun pressSend(s: JarvisAccessibilityService, wa: String, contact: String?): String {
        val end = System.currentTimeMillis() + 25000; var pressed = 0; var miss = 0
        while (System.currentTimeMillis() < end && pressed < 3) {
            val send = s.findById("$wa:id/send", wa) ?: s.findByText("Send", wa)
            if (send == null) { if (pressed > 0 && ++miss >= 3) break; Thread.sleep(500) }
            else { if (!s.click(send)) return "error: could not press Send"; pressed++; Thread.sleep(1300); miss = 0 }
        }
        if (pressed == 0) return "error: WhatsApp's Send button was not found, so nothing was sent"
        Thread.sleep(600)
        val open = contact != null && s.findById("$wa:id/conversation_contact_name", wa)?.let { norm(it.text?.toString() ?: "").let { t -> t.isNotEmpty() && (t.contains(norm(contact)) || norm(contact).contains(t)) } } == true
        return if (contact != null) (if (open) "ok: sent to '$contact' (their chat opened, confirmed on screen)" else "ok: Send pressed ($pressed time), please verify in the chat")
        else "ok: Send pressed ($pressed time) and WhatsApp closed the share screen; the Status should be up (check Updates > My status)"
    }

    // ---------------- Instagram / Facebook story ----------------
    private val PUBLISH = setOf("your story", "your stories", "add to your story", "share to your story", "share to story", "share to stories", "share now", "share story", "add to story", "आपकी स्टोरी", "अपनी स्टोरी")
    private val NEXT = setOf("next", "अगला"); private val SHARE = setOf("share", "शेयर करें", "साझा करें")
    private val FORBID = listOf("subscribe", "subscription", "meta verified", "get verified", "verified badge", "upgrade", "membership", "free trial", "premium")
    private val FORBID_ID = listOf("subscri", "verified", "paywall", "upsell", "upgrade", "membership", "premium", "billing", "purchase", "payment")
    private val COMPOSER = listOf("close friends", "your story", "share to", "add to your story", "stickers", "sticker", "effects", "draw", "music", "mention", "tag people", "add link", "aa")
    private val ERRORS = listOf("couldn't share", "could not share", "couldn't post", "try again", "something went wrong", "failed to share", "upload failed", "can't share")
    private val BILLING = Regex("(₹|\\$|€|£|rs\\.?)\\s?\\d|\\d\\s?(/|per )\\s?(mo|month|year|yr)|\\bper month\\b|\\bbilled\\b|\\bfree trial\\b|\\bcancel anytime\\b|\\bauto-?renew", RegexOption.IGNORE_CASE)
    private val PAYWALL_CTA = setOf("subscribe", "subscribe now", "get meta verified", "start free trial", "upgrade", "upgrade now", "continue to payment", "subscribe to meta verified")
    private fun rank(label: String): Int { val l = label.trim().lowercase(); return when { l in PUBLISH -> 3; l in SHARE -> 2; l in NEXT -> 1; else -> 0 } }
    private fun forbidden(labels: List<String>, id: String?) = labels.any { l -> FORBID.any { l.lowercase().contains(it) } } || (id ?: "").lowercase().let { i -> FORBID_ID.any { i.contains(it) } }
    private fun isPaywall(texts: List<String>, clickable: List<String>): Boolean {
        val low = texts.map { it.lowercase() }
        if (low.any { t -> listOf("meta verified", "get verified", "subscribe", "subscription", "upgrade plan", "payment required", "verified badge").any { t.contains(it) } } && clickable.any { it.lowercase() in PAYWALL_CTA }) return true
        return texts.any { BILLING.containsMatchIn(it) } && clickable.any { it.lowercase() in PAYWALL_CTA }
    }

    fun postStory(platform: String, type: String, which: String, nth: Int): String {
        val insta = platform.lowercase().contains("insta"); val pkg = if (insta) "com.instagram.android" else "com.facebook.katana"; val title = if (insta) "Instagram" else "Facebook"
        val video = type.lowercase().contains("video")
        if (!phone.installed(pkg)) return "error: $title is not installed"
        val s = svc() ?: return noA11y
        if (!hasMediaPermission(video)) return "error: Photos/media permission is needed. Allow it and ask again."
        val m = findMedia(video, which, nth) ?: return "error: no ${if (video) "video" else "photo"} found on the phone (${which}, #$nth)"
        grant(pkg, m)
        val intent = if (insta) Intent("com.instagram.share.ADD_TO_STORY").setDataAndType(m.uri, m.mime).setPackage(pkg).putExtra("source_application", ctx.packageName).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        else shareIntent(m, pkg)
        if (!phone.launch(intent)) return "error: the $title story screen did not open"
        if (!s.waitForPackage(pkg, 15000)) return "error: $title did not come to the screen. I stopped and pressed nothing."
        val steps = ArrayList<String>(); val count = HashMap<String, Int>(); val lastSig = HashMap<String, Int>()
        val start = System.currentTimeMillis(); val end = start + 90000; var published = false; var composer = false
        while (System.currentTimeMillis() < end) {
            val now = s.currentPackage()
            if (now == null) { Thread.sleep(500); continue }
            if (!now.startsWith(pkg)) { if (published) break; if (System.currentTimeMillis() - start > 25000 && steps.isEmpty()) return "error: the $title story screen never appeared (the screen shows $now). I pressed nothing."; Thread.sleep(600); continue }
            val nodes = s.findNodes(pkg) { true }
            val visible = nodes.filter { it.isVisibleToUser }
            val texts = visible.flatMap { labelsOf(it) }
            val clickables = visible.filter { it.isClickable || s.clickableAncestor(it) != null }
            val clickLabels = clickables.flatMap { labelsOf(it) }
            val sig = texts.hashCode()
            if (isPaywall(texts, clickLabels)) return "error: a subscription / Meta Verified screen blocked the $title story. I pressed nothing there and did not bypass it. Steps: ${steps.joinToString(" > ").ifEmpty { "none" }}"
            if (texts.any { t -> COMPOSER.any { t.lowercase().contains(it) && it != "aa" } }) composer = true
            if (composer || steps.isNotEmpty()) texts.firstOrNull { t -> ERRORS.any { t.lowercase().contains(it) } }?.let { return "error: $title showed: \"$it\". The story was not uploaded. Steps: ${steps.joinToString(" > ")}" }
            var best: Pair<String, AccessibilityNodeInfo>? = null; var br = 0
            if (composer) for (n in clickables) { val ls = labelsOf(n); if (forbidden(ls, n.viewIdResourceName)) continue
                for (l in ls) { val r = rank(l); if (r > br && (count[l.lowercase()] ?: 0) < 3 || (r > br && lastSig[l.lowercase()] != sig)) { br = r; best = Pair(l, n) } } }
            if (best != null) {
                val (label, node) = best
                if (!s.pressNode(node)) return "error: could not press '$label'. Steps: ${steps.joinToString(" > ")}"
                count[label.lowercase()] = (count[label.lowercase()] ?: 0) + 1; lastSig[label.lowercase()] = sig; steps.add(label)
                if (br >= 2) published = true
                Thread.sleep(1500)
            } else Thread.sleep(800)
        }
        return if (published) "ok: pressed ${steps.joinToString(" > ")} on $title. The story should be up; check the story ring on your profile."
        else "error: could not reach the Share button on $title. Steps: ${steps.joinToString(" > ").ifEmpty { "none" }}"
    }
}
