package com.jarvis.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.KeyguardManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.util.DisplayMetrics
import android.view.Display
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeoutOrNull
import java.io.ByteArrayOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Phone control. The node-finding, clicking, typing and pattern-drawing logic follows the approach that is proven on a real phone
 * in Mira's accessibility service (grid detection from the lock-screen view, click on clickable ancestors, robust text entry).
 */
class JarvisAccessibilityService : AccessibilityService() {
    companion object { @Volatile var inst: JarvisAccessibilityService? = null }
    data class PatternResult(val completed: Boolean, val gridSource: String, val message: String)
    private val patternBusy = AtomicBoolean(false)

    override fun onServiceConnected() { inst = this }
    override fun onUnbind(intent: Intent?): Boolean { inst = null; return super.onUnbind(intent) }
    override fun onDestroy() { inst = null; super.onDestroy() }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    // ---------- system buttons ----------
    fun performGlobal(button: String): Boolean {
        val a = when (button.lowercase().replace(" ", "_")) {
            "back" -> GLOBAL_ACTION_BACK; "home" -> GLOBAL_ACTION_HOME; "recents", "recent" -> GLOBAL_ACTION_RECENTS
            "notifications" -> GLOBAL_ACTION_NOTIFICATIONS; "quick_settings" -> GLOBAL_ACTION_QUICK_SETTINGS
            "lock_screen", "lock" -> if (Build.VERSION.SDK_INT >= 28) GLOBAL_ACTION_LOCK_SCREEN else return false
            "screenshot" -> if (Build.VERSION.SDK_INT >= 28) GLOBAL_ACTION_TAKE_SCREENSHOT else return false
            "power_menu", "power" -> GLOBAL_ACTION_POWER_DIALOG
            else -> return false
        }
        return performGlobalAction(a)
    }
    fun press(name: String): String = if (performGlobal(name)) "ok" else "error: '$name' refused (valid: back, home, recents, notifications, quick_settings, lock_screen, screenshot, power_menu)"

    // ---------- screen geometry ----------
    private fun realScreenBounds(): Rect {
        if (Build.VERSION.SDK_INT >= 30) return (getSystemService(WINDOW_SERVICE) as WindowManager).maximumWindowMetrics.bounds
        val dm = DisplayMetrics(); @Suppress("DEPRECATION") (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
        return Rect(0, 0, dm.widthPixels, dm.heightPixels)
    }

    // ---------- tree walking and finding ----------
    private fun walk(node: AccessibilityNodeInfo, depth: Int, visit: (AccessibilityNodeInfo) -> Boolean): Boolean {
        if (depth > 60) return true
        if (!visit(node)) return false
        for (i in 0 until node.childCount) { val c = try { node.getChild(i) } catch (e: Exception) { null } ?: continue; if (!walk(c, depth + 1, visit)) return false }
        return true
    }
    fun currentPackage(): String? = rootInActiveWindow?.packageName?.toString()
    fun waitForPackage(prefix: String, timeoutMs: Long): Boolean {
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end) { if (currentPackage()?.startsWith(prefix) == true) return true; Thread.sleep(200) }
        return false
    }
    private fun rootsFor(pkg: String?): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>(); val active = rootInActiveWindow
        if (pkg == null) { if (active != null) out.add(active); return out }
        if (active != null && active.packageName?.toString() == pkg) out.add(active)
        try { windows.forEach { w -> val r = w.root; if (r != null && r.packageName?.toString() == pkg && out.none { it == r }) out.add(r) } } catch (e: Exception) {}
        return out
    }
    fun findById(fullId: String, pkg: String? = null): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        if (pkg != null && root.packageName?.toString() != pkg) return null
        return try { root.findAccessibilityNodeInfosByViewId(fullId)?.firstOrNull() } catch (e: Exception) { null }
    }
    fun findByText(query: String, pkg: String? = null): AccessibilityNodeInfo? {
        val q = query.trim().lowercase(); if (q.isEmpty()) return null
        var exact: AccessibilityNodeInfo? = null; var partial: AccessibilityNodeInfo? = null
        for (r in rootsFor(pkg)) { walk(r, 0) { n ->
            if (n.isPassword) return@walk true
            for (t in listOfNotNull(n.text?.toString(), n.contentDescription?.toString(), n.hintText?.toString())) {
                val l = t.trim().lowercase()
                if (l == q) { exact = n; return@walk false }
                if (partial == null && l.contains(q)) partial = n
            }; true }
            if (exact != null) break }
        return exact ?: partial
    }
    fun findEditable(pkg: String? = null): AccessibilityNodeInfo? {
        val roots = rootsFor(pkg)
        for (r in roots) try { val f = r.findFocus(AccessibilityNodeInfo.FOCUS_INPUT); if (f != null && f.isEditable) return f } catch (e: Exception) {}
        var found: AccessibilityNodeInfo? = null
        for (r in roots) { walk(r, 0) { n -> if (!n.isEditable || n.isPassword) true else { found = n; false } }; if (found != null) break }
        return found
    }
    fun findNodes(pkg: String? = null, matcher: (AccessibilityNodeInfo) -> Boolean): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        for (r in rootsFor(pkg)) walk(r, 0) { n -> if (!n.isPassword && matcher(n)) out.add(n); true }
        return out
    }
    fun waitFor(timeoutMs: Long, finder: () -> AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end) { finder()?.let { return it }; Thread.sleep(250) }
        return null
    }

    // ---------- gestures (blocking: call from a background thread) ----------
    private fun dispatchAndWait(g: GestureDescription, timeoutMs: Long): Boolean {
        val latch = CountDownLatch(1); val ok = AtomicBoolean(false)
        val accepted = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { ok.set(true); latch.countDown() }
            override fun onCancelled(d: GestureDescription?) { latch.countDown() }
        }, null)
        if (!accepted) return false
        latch.await(timeoutMs, TimeUnit.MILLISECONDS); return ok.get()
    }
    fun swipeBlocking(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long): Boolean {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        return dispatchAndWait(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, ms)).build(), ms + 1400)
    }
    fun tapAt(x: Float, y: Float): Boolean {
        val p = Path().apply { moveTo(x, y) }
        return dispatchAndWait(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build(), 1500)
    }
    fun tapCenter(node: AccessibilityNodeInfo): Boolean { val r = Rect(); node.getBoundsInScreen(r); return if (r.isEmpty) false else tapAt(r.exactCenterX(), r.exactCenterY()) }
    fun clickableAncestor(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? { var n = node; var i = 0; while (n != null && i < 7) { if (n.isClickable && n.isEnabled) return n; n = n.parent; i++ }; return null }
    fun click(node: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = node; var i = 0
        while (n != null && i < 7) { if (n.isClickable && n.isEnabled && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true; n = n.parent; i++ }
        return tapCenter(node)
    }
    fun pressNode(node: AccessibilityNodeInfo): Boolean { val t = clickableAncestor(node) ?: node; return if (t.isVisibleToUser && tapCenter(t)) true else click(node) }

    // ---------- text ----------
    fun setText(node: AccessibilityNodeInfo, text: String): Boolean {
        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val b = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }
    fun setTextRobust(node: AccessibilityNodeInfo, text: String): Boolean {
        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS); node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        val b = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        val set = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
        if (set) { try { node.refresh() } catch (e: Exception) {}; if (node.text?.toString() == text) return true }
        return try {
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("jarvis", text))
            node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            val sel = Bundle().apply { putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, 0); putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, node.text?.length ?: 0) }
            node.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, sel)
            node.performAction(AccessibilityNodeInfo.ACTION_PASTE) || set
        } catch (e: Exception) { set }
    }
    fun commitTextViaIme(text: String, replaceExisting: Boolean = true): Boolean {
        if (Build.VERSION.SDK_INT < 33) return false
        return try { val ic = inputMethod?.currentInputConnection ?: return false
            if (replaceExisting) ic.deleteSurroundingText(200, 200); ic.commitText(text, 1, null); true } catch (t: Throwable) { false }
    }
    fun typeText(text: String): String {
        val n = findEditable() ?: return "error: no text field is focused"
        return if (setTextRobust(n, text) || commitTextViaIme(text)) "ok" else "error: could not type the text"
    }
    fun scroll(direction: String): Boolean {
        val root = rootInActiveWindow ?: return false; var target: AccessibilityNodeInfo? = null
        walk(root, 0) { n -> if (!n.isScrollable) true else { target = n; false } }
        val back = direction.lowercase().let { it == "up" || it == "left" }
        return target?.performAction(if (back) AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD else AccessibilityNodeInfo.ACTION_SCROLL_FORWARD) ?: false
    }
    fun readScreen(maxChars: Int = 1500): String {
        val root = rootInActiveWindow ?: return ""; val seen = LinkedHashSet<String>(); var len = 0
        walk(root, 0) { n -> if (n.isPassword) return@walk true
            val t = (n.text ?: n.contentDescription)?.toString()?.trim() ?: ""
            if (t.isNotEmpty() && seen.add(t)) len += t.length + 3
            len < maxChars }
        return seen.joinToString(" | ").take(maxChars)
    }
    fun describeScreen(): String { val s = readScreen(2500); return if (s.isBlank()) "error: no screen content" else s }

    // ---------- lock-screen pattern ----------
    private fun detectPatternGridBounds(): Rect? {
        val screen = realScreenBounds(); var best: Rect? = null
        val roots = ArrayList<AccessibilityNodeInfo>()
        try { rootInActiveWindow?.let { roots.add(it) } } catch (e: Exception) {}
        try { windows.forEach { w -> w.root?.let { roots.add(it) } } } catch (e: Exception) {}
        for (r in roots) try { walk(r, 0) { n ->
            val id = (n.viewIdResourceName ?: "").lowercase(); val cls = (n.className?.toString() ?: "").lowercase()
            val isPat = id.contains("lockpatternview") || id.contains("lock_pattern") || id.contains("patternview") || cls.contains("lockpatternview") || cls.contains("patternview")
            if (isPat) { val b = Rect(); n.getBoundsInScreen(b)
                if (!(b.width() < 200 || b.height() < 200 || b.width() > screen.width() * 1.01f || b.height() > screen.height() * 1.01f)) {
                    val cur = best; if (cur == null || b.width() * b.height() > cur.width() * cur.height()) best = b } }
            true } } catch (e: Exception) {}
        return best
    }
    /** Draws the pattern in one stroke. Dots are at the centres of the 3x3 cells of the detected (or configured) grid. */
    fun dispatchConfiguredPattern(pattern: String, cx: Float, cy: Float, sizeFrac: Float, speedMs: Long): PatternResult {
        if (pattern.length !in 4..9 || pattern.any { it !in '1'..'9' } || pattern.toSet().size != pattern.length) return PatternResult(false, "none", "Saved pattern is invalid (4-9 different dots, numbered 1-9).")
        if (!patternBusy.compareAndSet(false, true)) return PatternResult(false, "none", "An unlock gesture is already running.")
        try {
            val screen = realScreenBounds(); val det = detectPatternGridBounds()
            val left: Float; val top: Float; val cw: Float; val ch: Float; val src: String
            if (det != null) { left = det.left.toFloat(); top = det.top.toFloat(); cw = det.width() / 3f; ch = det.height() / 3f; src = "detected" }
            else { val w = screen.width().toFloat(); val h = screen.height().toFloat()
                val x = screen.left + cx.coerceIn(0.1f, 0.9f) * w; val y = screen.top + cy.coerceIn(0.1f, 0.9f) * h
                val size = sizeFrac.coerceIn(0.15f, 0.85f) * minOf(w, h); left = x - size / 2; top = y - size / 2; cw = size / 3f; ch = cw; src = "fallback" }
            val pts = pattern.map { val d = it - '1'; Pair(left + ((d % 3) + 0.5f) * cw, top + ((d / 3) + 0.5f) * ch) }
            if (pts.any { it.first < screen.left || it.first > screen.right || it.second < screen.top || it.second > screen.bottom }) return PatternResult(false, src, "The grid is off the screen: check the pattern position settings.")
            val path = Path().apply { moveTo(pts[0].first, pts[0].second); pts.drop(1).forEach { lineTo(it.first, it.second) } }
            val dur = maxOf(speedMs.coerceIn(250, 2500), (pts.size - 1) * 200L)
            val ok = dispatchAndWait(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, dur)).build(), dur + 1500)
            return if (ok) PatternResult(true, src, "Gesture complete.") else PatternResult(false, src, "The gesture was cancelled or rejected by the lock screen.")
        } finally { patternBusy.set(false) }
    }

    // ---------- coroutine-friendly helpers used by the screen agent ----------
    private suspend fun gesture(path: Path, dur: Long): Boolean {
        val done = CompletableDeferred<Boolean>()
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, dur)).build()
        if (!dispatchGesture(g, object : GestureResultCallback() { override fun onCompleted(d: GestureDescription?) { done.complete(true) }; override fun onCancelled(d: GestureDescription?) { done.complete(false) } }, null)) return false
        return withTimeoutOrNull(dur + 3000) { done.await() } ?: false
    }
    suspend fun tap(x: Float, y: Float) = gesture(Path().apply { moveTo(x, y) }, 60)
    suspend fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long = 350) = gesture(Path().apply { moveTo(x1, y1); lineTo(x2, y2) }, ms)
    suspend fun multi(strokes: List<FloatArray>, ms: Long): Boolean {
        val done = CompletableDeferred<Boolean>(); val b = GestureDescription.Builder()
        strokes.forEach { s -> b.addStroke(GestureDescription.StrokeDescription(Path().apply { moveTo(s[0], s[1]); if (s[2] != s[0] || s[3] != s[1]) lineTo(s[2], s[3]) }, 0, ms)) }
        if (!dispatchGesture(b.build(), object : GestureResultCallback() { override fun onCompleted(d: GestureDescription?) { done.complete(true) }; override fun onCancelled(d: GestureDescription?) { done.complete(false) } }, null)) return false
        return withTimeoutOrNull(ms + 3000) { done.await() } ?: false
    }
    suspend fun multiPaths(paths: List<Path>, ms: Long): Boolean {
        val done = CompletableDeferred<Boolean>(); val b = GestureDescription.Builder()
        paths.forEach { b.addStroke(GestureDescription.StrokeDescription(it, 0, ms)) }
        if (!dispatchGesture(b.build(), object : GestureResultCallback() { override fun onCompleted(d: GestureDescription?) { done.complete(true) }; override fun onCancelled(d: GestureDescription?) { done.complete(false) } }, null)) return false
        return withTimeoutOrNull(ms + 3000) { done.await() } ?: false
    }
    /** Screenshot as base64 JPEG plus an 8x8 brightness signature, used to detect that the game picture is not changing. */
    suspend fun screenshotWithSig(): Pair<String, IntArray>? {
        if (Build.VERSION.SDK_INT < 30) return null
        val d = CompletableDeferred<Pair<String, IntArray>?>()
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) { try {
                val hw = Bitmap.wrapHardwareBuffer(r.hardwareBuffer, r.colorSpace)!!; val bmp = hw.copy(Bitmap.Config.ARGB_8888, false); r.hardwareBuffer.close()
                val sc = Bitmap.createScaledBitmap(bmp, 540, (540f * bmp.height / bmp.width).toInt(), true)
                val tiny = Bitmap.createScaledBitmap(bmp, 8, 8, true); val sig = IntArray(64) { val c = tiny.getPixel(it % 8, it / 8); (android.graphics.Color.red(c) + android.graphics.Color.green(c) + android.graphics.Color.blue(c)) / 3 }
                val o = ByteArrayOutputStream(); sc.compress(Bitmap.CompressFormat.JPEG, 60, o); d.complete(Pair(Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP), sig))
            } catch (e: Exception) { d.complete(null) } }
            override fun onFailure(code: Int) { d.complete(null) }
        })
        return withTimeoutOrNull(4000) { d.await() }
    }
    suspend fun tapText(label: String): String { val n = findByText(label) ?: return "error: '$label' not found"; return if (click(n)) "ok" else "error: tap failed" }
    suspend fun closeCurrentApp(): String {
        if (!performGlobalAction(GLOBAL_ACTION_RECENTS)) return "error: recents refused"
        kotlinx.coroutines.delay(900)
        val b = realScreenBounds(); val w = b.width().toFloat(); val h = b.height().toFloat()
        val ok = swipe(w / 2, h * 0.55f, w / 2, h * 0.08f, 250); kotlinx.coroutines.delay(400); performGlobalAction(GLOBAL_ACTION_HOME)
        return if (ok) "ok: swiped the app away" else "error: swipe rejected"
    }
    suspend fun screenshotB64(): String? {
        if (Build.VERSION.SDK_INT < 30) return null
        val d = CompletableDeferred<String?>()
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) { try {
                val hw = Bitmap.wrapHardwareBuffer(r.hardwareBuffer, r.colorSpace)!!; val bmp = hw.copy(Bitmap.Config.ARGB_8888, false); r.hardwareBuffer.close()
                val sc = Bitmap.createScaledBitmap(bmp, 540, (540f * bmp.height / bmp.width).toInt(), true)
                val o = ByteArrayOutputStream(); sc.compress(Bitmap.CompressFormat.JPEG, 60, o); d.complete(Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP))
            } catch (e: Exception) { d.complete(null) } }
            override fun onFailure(code: Int) { d.complete(null) }
        })
        return withTimeoutOrNull(4000) { d.await() }
    }
}
