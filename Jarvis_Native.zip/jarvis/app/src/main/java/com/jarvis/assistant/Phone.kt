package com.jarvis.assistant

import android.Manifest
import android.app.KeyguardManager
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.PowerManager
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.telephony.TelephonyManager
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

/**
 * Phone actions with step-by-step verification. The flows (unlock, WhatsApp send, YouTube play, app search, calls) follow
 * the sequences that Mira runs successfully on a real phone. Every function returns "ok: ..." or "error: ..." and must be
 * called from a background thread (they wait for the screen to change).
 */
class Phone(private val ctx: Context, private val store: SecureStore) {
    private val pm get() = ctx.packageManager
    private fun svc() = JarvisAccessibilityService.inst
    private val noA11y = "error: Accessibility is OFF. Settings > Accessibility > Jarvis > turn it on."
    private fun norm(s: String) = s.lowercase(Locale.ROOT).filter { it.isLetterOrDigit() }

    /** Starts an activity from the accessibility service context, which Android allows from the background. */
    fun launch(i: Intent): Boolean = try { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); (svc() ?: ctx).startActivity(i); true } catch (e: Exception) { false }
    private fun launchView(uri: Uri, pkg: String?): Boolean {
        if (pkg != null && pm.getLaunchIntentForPackage(pkg) != null && launch(Intent(Intent.ACTION_VIEW, uri).setPackage(pkg))) return true
        return launch(Intent(Intent.ACTION_VIEW, uri))
    }

    // ---------------- screen: wake / lock / unlock ----------------
    fun wake(): String {
        val km = ctx.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager; val p = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        if (p.isInteractive && !km.isDeviceLocked) return "ok: the phone is already awake and unlocked"
        return try { @Suppress("DEPRECATION") p.newWakeLock(PowerManager.SCREEN_DIM_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP, "Jarvis:Wake").acquire(2500); "ok: screen wake requested" }
        catch (e: Exception) { "error: could not wake the screen: ${e.message}" }
    }
    fun lock(): String { val s = svc() ?: return noA11y; return if (s.performGlobal("lock_screen")) "ok: lock requested" else "error: Android refused the lock action" }
    private data class Try(val ok: Boolean, val msg: String, val source: String)
    private fun unlockOnce(cx: Float, cy: Float, size: Float): Try {
        val km = ctx.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        val s = svc() ?: return Try(false, noA11y, "none")
        val w = wake(); if (w.startsWith("error")) return Try(false, w, "none")
        Thread.sleep(1000)
        val b = ctx.resources.displayMetrics
        if (!s.swipeBlocking(b.widthPixels * 0.5f, b.heightPixels * 0.82f, b.widthPixels * 0.5f, b.heightPixels * 0.3f, 450)) return Try(false, "error: the swipe-up on the lock screen did not complete", "none")
        Thread.sleep(650)
        val r = s.dispatchConfiguredPattern(store.pattern, cx, cy, size, store.patternSpeed.toLong())
        if (!r.completed) return Try(false, "error: pattern not drawn: ${r.message}", r.gridSource)
        Thread.sleep(900)
        return if (!km.isDeviceLocked) Try(true, "ok: unlocked (grid ${r.gridSource})", r.gridSource) else Try(false, "error: the pattern was drawn (grid ${r.gridSource}) but the phone is still locked", r.gridSource)
    }
    fun unlock(): String {
        val km = ctx.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (!km.isDeviceLocked) return "ok: the phone is already unlocked"
        if (store.pattern.length !in 4..9) return "error: no pattern saved (Settings > Screen-lock pattern)"
        if (svc() == null) return noA11y
        return try { unlockOnce(store.gridX, store.gridY, store.gridSize).msg } catch (e: Exception) { "error: unlock failed: ${e.message}" }
    }
    /**
     * Test button: locks the phone, then unlocks it. If the lock-screen grid is detected there is exactly one try. If the saved position has to be used,
     * it tries up to 3 slightly different positions and keeps the one that works. It never makes more than 3 tries, because Android pauses the lock
     * screen for 30 seconds after 5 wrong patterns.
     */
    fun selfTestUnlock(): String {
        if (store.pattern.length !in 4..9) return "error: save your pattern first"
        val s = svc() ?: return noA11y
        val km = ctx.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (!km.isDeviceLocked) { if (!s.performGlobal("lock_screen")) return "error: could not lock the phone for the test"; Thread.sleep(2500) }
        val variants = listOf(Triple(store.gridX, store.gridY, store.gridSize), Triple(store.gridX, store.gridY - 0.06f, store.gridSize), Triple(store.gridX, store.gridY + 0.06f, store.gridSize * 1.15f))
        var report = ""
        for ((i, v) in variants.withIndex()) {
            val r = unlockOnce(v.first, v.second, v.third); report = r.msg
            if (r.ok) { if (r.source == "fallback") { store.gridY = v.second; store.gridSize = v.third; report += ". Saved the working position (Y ${(v.second * 100).toInt()}%, size ${(v.third * 100).toInt()}%)." }; return report }
            if (r.source != "fallback") break
            if (i < variants.lastIndex) Thread.sleep(1500)
        }
        return "$report. If this keeps failing, check the pattern numbers (1 top-left to 9 bottom-right) and the position fields in Settings."
    }

    // ---------------- apps ----------------
    private val aliases = mapOf("whatsapp" to listOf("com.whatsapp", "com.whatsapp.w4b"), "youtube" to listOf("com.google.android.youtube"), "yt" to listOf("com.google.android.youtube"),
        "chrome" to listOf("com.android.chrome"), "browser" to listOf("com.android.chrome"), "instagram" to listOf("com.instagram.android"), "facebook" to listOf("com.facebook.katana"),
        "telegram" to listOf("org.telegram.messenger"), "spotify" to listOf("com.spotify.music"), "maps" to listOf("com.google.android.apps.maps"), "playstore" to listOf("com.android.vending"),
        "chatgpt" to listOf("com.openai.chatgpt"), "gemini" to listOf("com.google.android.apps.bard"), "minecraft" to listOf("com.mojang.minecraftpe"), "snapchat" to listOf("com.snapchat.android"))
    private fun findLauncherPackage(name: String): String? {
        val q = norm(name); if (q.isEmpty()) return null
        val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        var best: String? = null; var bs = 0
        for (r in list) { val l = norm(r.loadLabel(pm).toString()); if (l.isEmpty()) continue
            val sc = when { l == q -> 3; l.startsWith(q) -> 2; l.contains(q) || (l.length >= 3 && q.contains(l)) -> 1; else -> 0 }
            if (sc > bs) { bs = sc; best = r.activityInfo.packageName } }
        return best
    }
    fun openApp(nameRaw: String): String {
        val n = nameRaw.trim(); if (n.isEmpty()) return "error: app name is empty"; val q = norm(n)
        if (q.contains("setting")) return if (launch(Intent(Settings.ACTION_SETTINGS))) "ok: Settings opened" else "error: could not open Settings"
        val cands = if (q.contains("whatsapp") && q.contains("business")) listOf("com.whatsapp.w4b") else aliases.entries.firstOrNull { q.contains(it.key) || q == it.key }?.value ?: emptyList()
        for (p in cands) pm.getLaunchIntentForPackage(p)?.let { if (launch(it)) return "ok: $n opened" }
        val pkg = findLauncherPackage(n) ?: return "error: no app named '$n' on this phone"
        val i = pm.getLaunchIntentForPackage(pkg) ?: return "error: '$n' has no launch screen"
        return if (launch(i)) "ok: $n opened" else "error: could not open '$n'"
    }

    // ---------------- YouTube: search and actually play ----------------
    private val YT = "com.google.android.youtube"
    fun playYouTube(queryRaw: String): String {
        val q = queryRaw.trim(); if (q.isEmpty()) return "error: query is empty"
        if (pm.getLaunchIntentForPackage(YT) == null) return "error: the YouTube app is not installed, so a video cannot be auto-played"
        val s = svc() ?: return noA11y
        if (!launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))).setPackage(YT))) return "error: could not open YouTube search"
        if (!s.waitForPackage(YT, 10000)) return "error: YouTube did not come to the screen"
        Thread.sleep(1500)
        val words = q.lowercase().split(Regex("\\s+")).map { norm(it) }.filter { it.length >= 2 }
        fun tile(n: AccessibilityNodeInfo): Boolean { val d = n.contentDescription?.toString()?.lowercase() ?: return false; return d.contains(" - ") && d.contains("play video") || (d.contains("minutes") || d.contains("seconds")) && d.contains(" - ") && n.isClickable }
        fun desc(n: AccessibilityNodeInfo) = norm((n.contentDescription ?: n.text)?.toString() ?: "")
        fun score(n: AccessibilityNodeInfo) = words.count { desc(n).contains(it) }
        var tiles: List<AccessibilityNodeInfo> = emptyList(); val end = System.currentTimeMillis() + 15000; var good = true
        while (System.currentTimeMillis() < end) {
            tiles = s.findNodes(YT) { tile(it) }
            if (tiles.any { score(it) > 0 }) break
            if (tiles.isNotEmpty() && System.currentTimeMillis() > end - 6000) { good = false; break }
            Thread.sleep(400)
        }
        if (tiles.isEmpty()) return "error: no YouTube results appeared (check internet or the screen)"
        Thread.sleep(600)
        var best = tiles.first(); var bsc = if (good) score(best) else 0
        for (t in tiles) { val sc = score(t); if (sc > bsc) { best = t; bsc = sc } }
        val title = (best.contentDescription?.toString() ?: q).split(" - ").firstOrNull()?.trim() ?: q
        if (!s.click(best)) return "error: could not tap the video"
        val player = s.waitFor(6000) { s.findNodes(YT) { n -> val id = n.viewIdResourceName ?: ""; id.endsWith(":id/watch_player") || id.endsWith(":id/player_view") }.firstOrNull() }
            ?: return "ok: tapped '$title' but could not confirm that the player opened"
        Thread.sleep(1200)
        s.findNodes(YT) { n -> n.isClickable && (n.contentDescription?.toString()?.trim().equals("play video", true)) }.firstOrNull()?.let { s.click(it) }
        return "ok: playing '$title' on YouTube"
    }

    // ---------------- contacts ----------------
    data class Contact(val id: Long, val name: String, val numbers: List<String>)
    private fun hasContacts() = ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
    fun findContact(raw: String): Contact? {
        if (!hasContacts()) return null; val q = norm(raw); if (q.isEmpty()) return null
        val byId = LinkedHashMap<Long, Pair<String, MutableList<String>>>()
        ctx.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, arrayOf(ContactsContract.CommonDataKinds.Phone.CONTACT_ID, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER), null, null, null)?.use { c ->
            while (c.moveToNext()) byId.getOrPut(c.getLong(0)) { Pair(c.getString(1) ?: "", mutableListOf()) }.second.add(c.getString(2) ?: "") }
        var best: Contact? = null; var bs = 0
        for ((id, v) in byId) { val n = norm(v.first); if (n.isEmpty()) continue
            val toks = v.first.lowercase().split(Regex("\\W+")).filter { it.isNotEmpty() }
            val sc = when { n == q -> 100; n.startsWith(q) -> 80; toks.any { norm(it) == q } -> 70; n.contains(q) -> 60; q.contains(n) && n.length >= 3 -> 40; else -> 0 }
            if (sc > bs) { bs = sc; best = Contact(id, v.first, v.second) } }
        return best
    }
    private fun callingCode(): String? {
        val iso = (ctx.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager)?.let { it.simCountryIso.ifBlank { it.networkCountryIso } }?.lowercase() ?: return null
        return mapOf("in" to "91", "us" to "1", "ca" to "1", "gb" to "44", "pk" to "92", "bd" to "880", "np" to "977", "lk" to "94", "ae" to "971", "sa" to "966", "au" to "61", "de" to "49", "fr" to "33", "id" to "62", "my" to "60", "sg" to "65", "za" to "27", "ng" to "234", "br" to "55", "ph" to "63", "tr" to "90", "ru" to "7")[iso]
    }
    private fun international(number: String): String? {
        val d = number.filter { it.isDigit() }
        return when { number.trim().startsWith("+") -> d; number.trim().startsWith("00") -> d.drop(2)
            else -> { val code = callingCode() ?: return null; val t = d.trimStart('0'); if (t.length in 7..11) code + t else null } }
    }
    private fun waProfileUri(contactId: Long): Uri? =
        ctx.contentResolver.query(ContactsContract.Data.CONTENT_URI, arrayOf(ContactsContract.Data._ID), "${ContactsContract.Data.CONTACT_ID}=? AND ${ContactsContract.Data.MIMETYPE}=?", arrayOf(contactId.toString(), "vnd.android.cursor.item/vnd.com.whatsapp.profile"), null)
            ?.use { if (it.moveToFirst()) ContentUris.withAppendedId(ContactsContract.Data.CONTENT_URI, it.getLong(0)) else null }

    // ---------------- WhatsApp: open chat, type, press Send, verify ----------------
    fun sendWhatsApp(contactRaw: String, messageRaw: String): String {
        val who = contactRaw.trim(); val msg = messageRaw.trim()
        if (who.isEmpty()) return "error: contact name is empty"; if (msg.isEmpty()) return "error: message is empty"
        val pkg = listOf("com.whatsapp", "com.whatsapp.w4b").firstOrNull { pm.getLaunchIntentForPackage(it) != null } ?: return "error: WhatsApp is not installed"
        val s = svc() ?: return noA11y
        if (!hasContacts()) return "error: Contacts permission is needed. Allow it and ask again."
        val c = findContact(who) ?: return "error: no saved contact named '$who'"
        val intl = c.numbers.firstNotNullOfOrNull { international(it) }
        val prefilled = intl != null
        val intent = if (intl != null) Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$intl?text=" + Uri.encode(msg))).setPackage(pkg)
        else { val u = waProfileUri(c.id) ?: return "error: '${c.name}' has a number without a country code and was not found on WhatsApp"; Intent(Intent.ACTION_VIEW).setDataAndType(u, "vnd.android.cursor.item/vnd.com.whatsapp.profile").setPackage(pkg) }
        if (!launch(intent)) return "error: could not open the WhatsApp chat"
        return fillAndSend(s, pkg, msg, c.name, prefilled)
    }
    private fun fillAndSend(s: JarvisAccessibilityService, pkg: String, message: String, who: String, prefilled: Boolean): String {
        if (!s.waitForPackage(pkg, 8000)) return "error: WhatsApp did not come to the screen"
        fun entry() = s.findById("$pkg:id/entry", pkg) ?: s.findEditable(pkg)
        if (prefilled) s.waitFor(5000) { entry()?.takeIf { it.text?.toString()?.trim() == message } }
        else { val wn = norm(who); s.waitFor(5000) { s.findById("$pkg:id/conversation_contact_name", pkg)?.takeIf { val t = norm(it.text?.toString() ?: ""); t.isNotEmpty() && (wn.contains(t) || t.contains(wn)) } } }
        var box = s.waitFor(8000) { entry() } ?: return "error: the chat message box was not found (maybe this number is not on WhatsApp)"
        Thread.sleep(500)
        if (box.text?.toString()?.trim() != message) { entry()?.let { box = it }; if (!s.setText(box, message)) return "error: could not type the message"; Thread.sleep(600) }
        repeat(2) {
            val send = s.waitFor(4000) { s.findById("$pkg:id/send", pkg) ?: s.findByText("Send", pkg) } ?: return "error: WhatsApp's Send button was not found"
            if (!s.click(send)) return "error: could not press Send"
            if (s.waitFor(2500) { entry()?.takeIf { it.text?.toString()?.trim() != message } } != null) return "ok: message to '$who' typed and sent"
        }
        return "error: Send was pressed but delivery could not be confirmed"
    }

    // ---------------- calls, SMS ----------------
    fun call(numberRaw: String, contactName: String, direct: Boolean = true): String {
        var number = numberRaw.trim(); var shown = ""
        if (number.isEmpty() && contactName.isNotBlank()) {
            if (!hasContacts()) return "error: Contacts permission is needed. Allow it and ask again."
            val c = findContact(contactName) ?: return "error: no saved contact named '$contactName'"
            number = c.numbers.firstOrNull() ?: return "error: ${c.name} has no phone number"; shown = c.name
        }
        number = number.filter { it.isDigit() || it == '+' || it == '*' || it == '#' }; if (number.isEmpty()) return "error: a phone number or contact name is needed"
        val label = if (shown.isNotEmpty()) "$shown ($number)" else number; val uri = Uri.parse("tel:" + Uri.encode(number))
        if (!direct) return if (launch(Intent(Intent.ACTION_DIAL, uri))) "ok: dialer opened for $label" else "error: could not open the dialer"
        if (ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED)
            return if (launch(Intent(Intent.ACTION_CALL, uri))) "ok: calling $label" else if (launch(Intent(Intent.ACTION_DIAL, uri))) "ok: dialer opened for $label (direct call was refused)" else "error: could not start the call"
        return if (launch(Intent(Intent.ACTION_DIAL, uri))) "ok: no call permission yet, so the number is in the dialer for $label" else "error: call permission is needed"
    }
    fun composeSms(numberRaw: String, message: String, contactName: String, send: Boolean): String {
        var number = numberRaw.trim()
        if (number.isEmpty() && contactName.isNotBlank()) { val c = findContact(contactName) ?: return "error: no saved contact named '$contactName'"; number = c.numbers.firstOrNull() ?: return "error: ${c.name} has no phone number" }
        number = number.filter { it.isDigit() || it == '+' }; if (number.isEmpty()) return "error: a phone number or contact name is needed"
        if (!launch(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number")).putExtra("sms_body", message))) return "error: could not open the messaging app"
        if (!send) return "ok: message written, not sent yet"
        val s = svc() ?: return "ok: message written, but Accessibility is off so it was not sent"
        Thread.sleep(1500)
        val btn = s.waitFor(5000) { s.findById("com.samsung.android.messaging:id/send_button1") ?: s.findById("com.google.android.apps.messaging:id/send_message_button_icon") ?: s.findByText("Send SMS") ?: s.findByText("Send") } ?: return "ok: message written, but the Send button was not found"
        return if (s.click(btn)) "ok: text message sent" else "error: could not press Send"
    }

    fun installed(pkg: String) = pm.getLaunchIntentForPackage(pkg) != null

    // ---------------- Play Store, uninstall, quick-setting toggles ----------------
    fun installApp(nameRaw: String): String {
        val name = nameRaw.trim(); if (name.isEmpty()) return "error: app name is empty"
        findLauncherPackage(name)?.let { return "ok: '$name' is already installed" }
        val s = svc() ?: return noA11y; val vend = "com.android.vending"
        if (!launch(Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=" + Uri.encode(name) + "&c=apps")).setPackage(vend))) return "error: could not open the Play Store"
        if (!s.waitForPackage(vend, 10000)) return "error: the Play Store did not come to the screen"
        Thread.sleep(2500); val q = norm(name)
        val tile = s.waitFor(10000) { s.findNodes(vend) { n -> n.isClickable && norm((n.contentDescription ?: n.text)?.toString() ?: "").let { it.isNotEmpty() && it.contains(q) } }.firstOrNull() } ?: return "error: '$name' was not found in the Play Store results"
        if (!s.click(tile)) return "error: could not open the app page"
        Thread.sleep(2500)
        val btn = s.waitFor(10000) { s.findByText("Install", vend) }
            ?: return if (s.findByText("Open", vend) != null || s.findByText("Uninstall", vend) != null) "ok: '$name' is already installed" else "error: no Install button (paid app, device not supported, or sign-in needed)"
        if (!s.click(btn)) return "error: could not press Install"
        val done = s.waitFor(90000) { s.findByText("Open", vend) }
        return if (done != null) "ok: '$name' installed" else "ok: Install pressed; the download is still running"
    }
    fun uninstallApp(nameRaw: String): String {
        val pkg = findLauncherPackage(nameRaw.trim()) ?: return "error: no app named '$nameRaw' is installed"
        val s = svc() ?: return noA11y
        if (!launch(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")))) return "error: could not open the uninstall screen"
        val ok = s.waitFor(8000) { s.findByText("OK") ?: s.findByText("Uninstall") } ?: return "error: the uninstall confirmation did not appear"
        if (!s.click(ok)) return "error: could not confirm the uninstall"
        Thread.sleep(3000)
        return if (!installed(pkg)) "ok: '$nameRaw' uninstalled" else "error: '$nameRaw' is still installed (it may be a system app)"
    }
    fun toggleSetting(label: String, on: Boolean): String {
        val s = svc() ?: return noA11y; val l = label.trim(); if (l.isEmpty()) return "error: which setting?"
        s.performGlobal("quick_settings"); Thread.sleep(900)
        var tile = s.waitFor(2500) { s.findByText(l) }
        if (tile == null) { s.performGlobal("quick_settings"); Thread.sleep(700); tile = s.waitFor(2500) { s.findByText(l) } }
        if (tile == null) { s.performGlobal("back"); return "error: no quick-settings tile named '$l'" }
        fun state(n: AccessibilityNodeInfo): Boolean? {
            val d = ((if (android.os.Build.VERSION.SDK_INT >= 30) n.stateDescription else null) ?: n.contentDescription ?: "").toString().lowercase()
            return when { n.isCheckable -> n.isChecked; d.contains("off") -> false; d.contains(" on") || d.endsWith("on") -> true; else -> null }
        }
        val cur = state(tile)
        if (cur == on) { s.performGlobal("back"); return "ok: $l is already ${if (on) "on" else "off"}" }
        if (!s.click(tile)) { s.performGlobal("back"); return "error: could not tap the $l tile" }
        Thread.sleep(1000); val after = s.findByText(l)?.let { state(it) }
        s.performGlobal("back"); Thread.sleep(300); s.performGlobal("back")
        return if (after == null || after == on) "ok: $l turned ${if (on) "on" else "off"}" else "error: $l did not change"
    }

    // ---------------- alarms, timers, settings, volume ----------------
    fun setTimer(seconds: Int, label: String): String = if (launch(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, seconds).putExtra(AlarmClock.EXTRA_MESSAGE, label).putExtra(AlarmClock.EXTRA_SKIP_UI, true))) "ok: timer set for $seconds s" else "error: no clock app accepted the timer"
    fun setAlarm(hour: Int, minute: Int, label: String): String = if (launch(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, hour).putExtra(AlarmClock.EXTRA_MINUTES, minute).putExtra(AlarmClock.EXTRA_MESSAGE, label).putExtra(AlarmClock.EXTRA_SKIP_UI, true))) "ok: alarm set for %02d:%02d".format(hour, minute) else "error: no clock app accepted the alarm"
    fun openSettings(page: String): String {
        val a = when (page.lowercase().trim()) { "wifi", "wi-fi" -> Settings.ACTION_WIFI_SETTINGS; "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS; "display", "brightness" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound", "volume" -> Settings.ACTION_SOUND_SETTINGS; "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS; "apps" -> Settings.ACTION_APPLICATION_SETTINGS; "location", "gps" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "airplane", "flight" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS; "nfc" -> Settings.ACTION_NFC_SETTINGS; "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS; "data", "mobile data" -> Settings.ACTION_DATA_ROAMING_SETTINGS
            "storage" -> Settings.ACTION_INTERNAL_STORAGE_SETTINGS; "date", "time" -> Settings.ACTION_DATE_SETTINGS; "language" -> Settings.ACTION_LOCALE_SETTINGS; "notification", "notifications" -> Settings.ACTION_APP_NOTIFICATION_SETTINGS; else -> Settings.ACTION_SETTINGS }
        return if (launch(Intent(a).apply { if (a == Settings.ACTION_APP_NOTIFICATION_SETTINGS) putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName) })) "ok: $page settings opened" else "error: could not open settings"
    }
    fun volume(action: String, percent: Int?): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager; val st = android.media.AudioManager.STREAM_MUSIC; val max = am.getStreamMaxVolume(st)
        when (action.lowercase()) { "up", "raise", "increase" -> am.adjustStreamVolume(st, android.media.AudioManager.ADJUST_RAISE, android.media.AudioManager.FLAG_SHOW_UI)
            "down", "lower", "decrease" -> am.adjustStreamVolume(st, android.media.AudioManager.ADJUST_LOWER, android.media.AudioManager.FLAG_SHOW_UI)
            "mute" -> am.adjustStreamVolume(st, android.media.AudioManager.ADJUST_MUTE, android.media.AudioManager.FLAG_SHOW_UI); "unmute" -> am.adjustStreamVolume(st, android.media.AudioManager.ADJUST_UNMUTE, android.media.AudioManager.FLAG_SHOW_UI)
            else -> { val p = percent ?: return "error: say up, down, mute or a percentage"; am.setStreamVolume(st, (max * p.coerceIn(0, 100)) / 100, android.media.AudioManager.FLAG_SHOW_UI) } }
        return "ok: volume now ${am.getStreamVolume(st) * 100 / max}%"
    }

    // ---------------- screen reading / clicking ----------------
    fun readScreen(): String { val s = svc() ?: return noA11y; val t = s.readScreen(1800); return if (t.isBlank()) "ok: the screen has no readable text" else "ok: $t" }
    fun clickOnScreen(text: String): String { val s = svc() ?: return noA11y; val n = s.findByText(text) ?: return "error: '$text' is not visible on the screen"; return if (s.click(n)) "ok: tapped '$text'" else "error: could not tap '$text'" }
    fun scroll(direction: String): String { val s = svc() ?: return noA11y; return if (s.scroll(direction)) "ok: scrolled $direction" else "error: nothing scrollable on the screen" }
    fun type(text: String): String { val s = svc() ?: return noA11y; return s.typeText(text).let { if (it == "ok") "ok: typed" else it } }
}
