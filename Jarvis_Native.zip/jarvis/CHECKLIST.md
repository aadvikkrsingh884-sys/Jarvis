# Jarvis dream-project checklist

Legend: [B] built in this project, test it on your phone | [W] web version only | [N] not built yet (planned order below) | [X] not possible on Android, with the closest alternative

## 0. Install and first run (do in this order)
- [B] Build in Android Studio (Build > Build APK), install on the A50s
- [B] Settings: paste Gemini key (Get free key button) -> Test key
- [B] Enable Accessibility (Settings > Accessibility > Jarvis). Needed for unlock, app control, Minecraft
- [B] Allow: microphone, contacts, phone, notifications, camera, location
- [B] Display over other apps (floating orb), Notification access (message reading), All files access (create folders)
- [B] Battery: Unrestricted + Never sleeping apps (Samsung)
- [B] Save pattern (dots 1-9, 1 = top-left). Press "Test unlock now" (locks the phone, max 3 tries)

## 1. Unlock and lock (priority 1)
- [B] "Unlock my phone": wake screen, swipe up, draw pattern, confirm the phone really unlocked
- [B] Finds the lock-screen pattern grid automatically; falls back to saved X/Y/size/speed (50/68/38/900)
- [B] Self-test button auto-tunes the fallback position (never more than 3 tries, to avoid the 30-second Android lockout)
- [B] "Lock my phone"
- [B] Only-my-voice check for unlock, calls, texts, social and game tasks (basic)
- [X] Android allows only pattern drawing through Accessibility; PIN/password/fingerprint cannot be entered by apps

## 2. Minecraft agent (priority 2)
- [B] "Play Minecraft, mine 2 stacks of diamonds without dying": opens the game, enters your last world, runs a mission in the background
- [B] Learns where the joystick, jump, sneak, inventory and hotbar are from a screenshot
- [B] Real multi-finger control: walk + mine at the same time, look, jump, sneak, slot select, eat, inventory
- [B] Reads hearts, hunger, Y level, item count and danger from every screenshot
- [B] Safety supervisor: retreats from lava/void/drops, stops when health is critical, stops if the picture freezes
- [B] Progress spoken every few steps; "Stop" by voice or by the notification Stop button
- [B] Diamond plan: staircase down to Y -58, branch mining, torches, no digging straight down
- [N] Learned memory of your world (base location, chests), crafting and furnace flows, mob fighting tuned per weapon
- Before you start: Minecraft > Settings > Show Coordinates ON; hotbar: pickaxe, sword, food, torches, blocks

## 3. Calls, texts, apps
- [B] Open any app by name (fuzzy match), close app, home/back/recents/notifications/quick settings/power menu/screenshot
- [B] Call a contact by name or number (direct), dialer fallback
- [B] Write and send a text message (confirmation card first)
- [B] WhatsApp: open chat, type, press Send, verify (confirmation card first)
- [B] YouTube: search and play the right video
- [B] Open Settings pages, volume, alarms, timers, flashlight, battery, media keys, maps, web search
- [B] Read / tap / scroll / type on the current screen
- [B] "Look at the screen" with vision
- [B] WhatsApp photo/video to a contact, WhatsApp Status, Instagram/Facebook story as exact step flows (paywall guard, loop guard)
- [B] Play Store install, uninstall, quick-setting toggles by name, create files/folders by voice

## 4. Screen agent for any app (ChatGPT, Gemini, others)
- [B] See-and-act loop with screenshot + gestures + typing, risk questions before send/post/install/delete
- [B] Ask ChatGPT/Gemini apps a question and read the answer back
- [B] Social post (story/post/reel) with one confirmation and strict composer rules

## 5. Notifications and overlay
- [B] Reads new messages (WhatsApp, Telegram, SMS, others) and tells you who wrote what, then asks what to do
- [B] Floating orb with captions (tap = mute, long-press = open), notification cards, confirmation card over any app
- [B] Quick Settings tile to start/stop
- [B] Reply to a message by voice (tells you who wrote, then WhatsApp/SMS reply tools)

## 6. Voice and brain
- [B] Gemini Live voice, model gemini-3.8-live, tuned voice detection, session resume, auto-reconnect, echo gate
- [B] 8 roles incl. Girlfriend, auto role by mood, 1.0-1.5 s human pause, 30 voices, emotion style
- [B] Free providers (Groq, OpenRouter, Cerebras, Mistral, Gemini; OpenAI paid) for builders, documents, summaries; Get-key links and Test key
- [N] Classic voice (Android speech + Indian TTS) inside the native app

## 7. Look and feel
- [B] 18 themes with previews, Light Mode, splash, widgets, 4 tabs, TALK button
- [B] Anime-boy avatar, 4 slots for your own character images with background removal and framing
- [W] Real-time 3D avatar (web version only)
- [N] 3D avatar inside the native app, hand-painted artwork (needs an image from an image generator)

## 8. Create
- [B] Websites and games with preview and ZIP export, PDF resume/biodata/letter/report
- [N] Multi-file projects with continuation and self-check (Mira's coding engine)

## 9. Privacy and safety
- [B] Encrypted key/pattern/memory, no backup, in-memory or encrypted chat, wipe button
- [B] Confirmation card for calls, texts, WhatsApp, posts, installs
- [B] Treats screen and notification text as data, never as orders

## 10. How to get the APK
See README_BUILD_APK.txt (cloud build, no Android Studio needed).

## 11. Still not built
1. Native 3D avatar (web version has it), Classic voice in the native app, Mira-style multi-file coding engine
2. Fixes and tuning from your first real run (compile errors, unlock position, Minecraft controls)
