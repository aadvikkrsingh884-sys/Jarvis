# Jarvis – complete package

## Contents
- `app/` + Gradle files: native Android app (open in Android Studio). Everything below.
- The web version is a separate file (Jarvis_App.zip).

## Features (native app)
Voice: live Gemini voice, Indian-accent prompt, 1.0-1.5 s reply pause (adjustable), instant barge-in, echo/noise cancel, auto-reconnect, live captions.
Roles: Jarvis, Girlfriend, Big Brother, Little Brother, Sister, Best Friend, Mentor, Listener. Auto role switch by mood.
Look: 15 themes with animated backdrops (aurora, cyber grid, Matrix rain), animated face avatar with moods, orb core, 4-tab UI (Home, Chat, Create, Settings).
Phone: unlock by pattern, open/close apps, call, SMS, WhatsApp, YouTube, Maps, Play Store, settings pages, alarms, timers, flashlight, volume, media keys, battery, share, files and folders, notifications reader.
Agent: see-and-act loop for any app (ChatGPT, Gemini, WhatsApp, games like Minecraft), multi-finger gestures, stop on command.
Social: story/post/reel posting with one confirmation.
Create: websites and browser games (preview, ZIP/HTML export, edits), PDF resume/biodata/letter/report.
Camera: live camera vision. Overlay: floating orb (tap mute, long-press open), captions, notification cards, confirmation card over any app.
Security: AES-256 encrypted storage, no backups, in-memory chat, confirmation for risky actions, owner-voice check for sensitive actions (basic), Quick Settings tile.

## Added in the latest version
Splash screen | greeting + "Ready" chip | weather, date and mood cards | text chat box (Home and Chat) | Coding tab | Music, Study, Journal, Documents modes (journal saved encrypted) |
30 Gemini voices picker | emotion style | 18 themes with preview cards incl. Light Mode | status card for every permission | saved accounts (YouTube, Instagram, Facebook, Telegram: open and summarise) |
encrypted saved conversation + clear button + continuity in new sessions | big TALK button | camera "Describe" button | use your own image as the avatar (Settings > Choose my avatar image).
Also new: original anime-boy avatar (vector art, blinks, lip-sync, moods), 4 slots for your own character images with framing and background removal, multi-provider AI (Gemini, Groq, OpenRouter, Cerebras, Mistral, OpenAI) with Get-key buttons and key test. Live voice in the native app still needs a Gemini key.

## Build
1. Install Android Studio. File > Open > this folder. Wait for Gradle sync (needs internet once).
2. Build > Build APK(s). APK: `app/build/outputs/apk/debug/app-debug.apk`.
Test without an APK: turn on USB debugging on the phone, plug it in, select it in Android Studio, press Run.

## First run (Settings tab, do all)
Enable Accessibility | Display over other apps | Keep alive (Samsung: Battery > Background usage limits > Never sleeping apps) | Notification access | All files access | paste Gemini key | save | HOME > START.
Optional: Enroll my voice, then turn on "Only my voice".

## Modify
`Roles.kt` personalities and voices | `Themes.kt` colours | `ActionExecutor.kt` tools | `AgentLoop.kt` screen agent | `MainActivity.kt` UI | `AudioIO.kt` timing.

## Limits
Android blocks silent permission grants, screenshots in banking/secure screens, and lock-screen bypass beyond gestures Accessibility can draw. Agent tasks and games run 2-4 s per step and can fail. The voice check is basic and cannot stop a good recording. Not compiled by the author: send build errors for fixes.

## Phase A (Mira-derived, latest)
Ported from Mira's real code: Live voice settings (model gemini-3.8-live, voice-activity tuning, session resume, goAway, reconnect limits), audio pipeline (echo gate, soft gain, no noise suppressor, loudness boost, mic auto-restart),
accessibility flags (report view ids, IME), node finders and click/typing helpers, lock-screen pattern grid detection with fallback position, wake + swipe + pattern unlock with locked/unlocked verification,
opening apps from the accessibility context, app search by label, YouTube search-and-play, contact fuzzy match, WhatsApp open-chat-type-send-verify, direct calls, SMS compose + send, alarms/timers,
settings pages, volume, read/click/scroll/type on screen, and message-notification reading with Mira's filters.
Settings now has pattern position/size/speed (defaults 50 / 68 / 38 / 900).

## Phase B
Unlock self-test (Settings > "Test unlock now"), Minecraft mission agent (play_game), progress events, notification Stop button. See CHECKLIST.md.
