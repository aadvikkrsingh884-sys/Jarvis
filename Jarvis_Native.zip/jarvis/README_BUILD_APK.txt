GET THE APK WITHOUT INSTALLING ANDROID STUDIO (about 15 minutes, any computer, free)

1. Unzip Jarvis_Native.zip. You get a folder called jarvis.
2. Go to github.com, sign up (free), then New repository. Name: jarvis. Choose Private. Create.
3. On the new repository page click "uploading an existing file". Drag ALL the files and folders from inside the jarvis folder into the page. Click Commit changes.
   (Hidden folders may not upload; step 4 fixes that.)
4. In the repository click Add file > Create new file. In the name box type exactly:  .github/workflows/build-apk.yml
   Open build-apk.yml.txt from the jarvis folder, copy everything, paste it into the big box, click Commit changes.
5. Click the Actions tab > "Build Jarvis APK" > Run workflow > Run. Wait 6-10 minutes until it shows a green tick.
6. Click the finished run > scroll to Artifacts > Jarvis-APK. Download, unzip, you get app-debug.apk.
7. Send app-debug.apk to the phone and install it (allow "install unknown apps" for your file manager or browser).
8. If the run shows a red cross: open it, click the red step, copy the red error lines and send them to me. I will fix them and give you a new zip.

AFTER INSTALL (do in this order)
Open Jarvis > Settings: paste Gemini key (Get free key button) > Save.
Enable Accessibility (Jarvis), Display over other apps, Notification access, All files access; set battery to Unrestricted.
Save your unlock pattern (1 = top-left ... 9 = bottom-right), press "Test unlock now".
Home > START. Say: "unlock my phone", "play Minecraft and mine 2 stacks of diamonds", "WhatsApp Rahul hello".
