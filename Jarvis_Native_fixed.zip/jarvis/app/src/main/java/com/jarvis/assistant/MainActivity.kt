package com.jarvis.assistant

import android.Manifest
import android.content.*
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    private lateinit var store: SecureStore
    private lateinit var bgView: BackgroundView
    private lateinit var orb: OrbView
    private lateinit var avatar: AvatarView
    private lateinit var title: TextView
    private lateinit var greet: TextView
    private lateinit var ready: TextView
    private lateinit var roleName: TextView
    private lateinit var status: TextView
    private lateinit var chatBox: LinearLayout
    private lateinit var chatScroll: ScrollView
    private lateinit var createOut: TextView
    private lateinit var codeOut: TextView
    private lateinit var permCard: TextView
    private lateinit var themeGrid: GridLayout
    private lateinit var splash: FrameLayout
    private lateinit var talk: TextView
    private lateinit var wTemp: TextView; private lateinit var wSky: TextView; private lateinit var moodV: TextView
    private val tabs = mutableListOf<View>()
    private val tabBtns = mutableMapOf<Int, TextView>()
    private val roleChips = mutableMapOf<String, TextView>()
    private val themeChips = mutableMapOf<String, TextView>()
    private val styleChips = mutableMapOf<String, TextView>()
    private val modeChips = mutableMapOf<String, TextView>()
    private val buttons = mutableListOf<Button>()
    private val labels = mutableListOf<TextView>()
    private val cards = mutableListOf<View>()
    private val fgViews = mutableListOf<TextView>()
    private var saveFn: () -> Unit = {}
    private var curTab = 0
    private val ui = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val calm = Runnable { avatar.emotion = "neutral"; moodV.text = "Calm" }
    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) importAvatar(uri) }

    private val rx = object : BroadcastReceiver() { override fun onReceive(c: Context, i: Intent) {
        when (i.action) {
            "com.jarvis.STATUS" -> { val s = i.getStringExtra("s") ?: return; status.text = s
                val st = when { s.startsWith("Speaking") -> "speaking"; s.startsWith("Listening") -> "listening"; else -> "idle" }; orb.state = st; avatar.state = st
                ready.text = if (st == "idle") (if (s.startsWith("Stopped")) "Tap TALK to start" else s) else "Ready when you are" }
            "com.jarvis.EMOTION" -> { val e = i.getStringExtra("e") ?: "neutral"; avatar.emotion = e
                moodV.text = mapOf("happy" to "Happy", "sad" to "Low", "angry" to "Tense", "love" to "Warm", "surprised" to "Surprised")[e] ?: "Calm"
                ui.removeCallbacks(calm); ui.postDelayed(calm, 9000) }
            "com.jarvis.TEXT" -> refreshChat()
        } } }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun box(fill: Int, stroke: Int, r: Int = 8) = GradientDrawable().apply { cornerRadius = dp(r).toFloat(); setColor(fill); setStroke(dp(1), stroke) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b); store = SecureStore(this); Llm.store = store
        if (store.saveChat) Chat.load(store)
        val frame = FrameLayout(this); bgView = BackgroundView(this); frame.addView(bgView, FrameLayout.LayoutParams(-1, -1))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val content = FrameLayout(this)

        fun btn(t: String, onClick: () -> Unit) = Button(this).apply { text = t; isAllCaps = false; setOnClickListener { onClick() } }.also { buttons.add(it) }
        fun section(t: String) = TextView(this).apply { text = t; textSize = 11f; letterSpacing = 0.3f; setPadding(0, dp(18), 0, dp(6)) }.also { labels.add(it) }
        fun page(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(34), dp(18), dp(12)) }
        fun chipRow(items: List<Pair<String, String>>, reg: MutableMap<String, TextView>, onPick: (String) -> Unit): HorizontalScrollView {
            val hs = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            items.forEach { (id, name) -> val c = TextView(this).apply { text = name; textSize = 13f; setPadding(dp(14), dp(9), dp(14), dp(9)); setOnClickListener { onPick(id) } }
                reg[id] = c; r.addView(c, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(8) }) }
            hs.addView(r); return hs
        }
        fun lab(t: String) = TextView(this).apply { text = t; textSize = 11f; setPadding(0, dp(14), 0, dp(2)) }.also { labels.add(it) }
        fun edit(h: String, v: String, pw: Boolean = false) = EditText(this).apply { hint = h; setText(v)
            if (pw) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }.also { fgViews.add(it) }
        fun check(t: String, v: Boolean) = CheckBox(this).apply { text = t; isChecked = v }.also { fgViews.add(it) }
        fun input(hint: String, onSend: (String) -> Unit): LinearLayout {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val e = edit(hint, ""); val send = btn("Send") { val t = e.text.toString().trim(); if (t.isNotEmpty()) { onSend(t); e.setText("") } }
            row.addView(e, LinearLayout.LayoutParams(0, -2, 1f)); row.addView(send); return row
        }
        fun startJarvis() { saveFn(); askPerms(); ContextCompat.startForegroundService(this, Intent(this, JarvisService::class.java)) }
        fun stopJarvis() { stopService(Intent(this, JarvisService::class.java)); status.text = "Stopped"; ready.text = "Tap TALK to start"; orb.state = "idle"; avatar.state = "idle" }
        fun card(label: String, big: TextView, small: TextView?): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(10))
            addView(TextView(this@MainActivity).apply { text = label; textSize = 10f }.also { labels.add(it) }); addView(big); small?.let { addView(it) } }.also { cards.add(it) }

        // ================= HOME =================
        val home = page()
        greet = TextView(this).apply { textSize = 14f }.also { fgViews.add(it) }
        title = TextView(this).apply { text = "Jarvis"; textSize = 30f; typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD) }
        ready = TextView(this).apply { text = "Tap TALK to start"; textSize = 12f; setPadding(dp(12), dp(5), dp(12), dp(5)) }.also { cards.add(it) }
        roleName = TextView(this).apply { textSize = 11f; letterSpacing = 0.25f; setPadding(0, dp(6), 0, 0) }
        home.addView(greet); home.addView(title); home.addView(ready, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(6) }); home.addView(roleName)
        orb = OrbView(this); avatar = AvatarView(this)
        val stage = FrameLayout(this); stage.addView(orb, FrameLayout.LayoutParams(-1, -1)); stage.addView(avatar, FrameLayout.LayoutParams(-1, -1))
        stage.setOnClickListener { if (JarvisService.running) stopJarvis() else startJarvis() }
        home.addView(stage, LinearLayout.LayoutParams(-1, dp(290)))
        status = TextView(this).apply { text = "Idle"; textSize = 14f; gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(10)) }.also { fgViews.add(it) }
        home.addView(status)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(btn("START") { startJarvis() }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(6) })
        row.addView(btn("CAMERA") { startActivity(Intent(this, CameraActivity::class.java)) }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(6) })
        row.addView(btn("STOP") { stopJarvis() }, LinearLayout.LayoutParams(0, -2, 1f))
        home.addView(row)
        // widgets
        wTemp = TextView(this).apply { text = "--"; textSize = 22f; typeface = Typeface.DEFAULT_BOLD }.also { fgViews.add(it) }
        wSky = TextView(this).apply { text = "Allow location"; textSize = 11f }.also { fgViews.add(it) }
        val dayBig = TextView(this).apply { text = SimpleDateFormat("d", Locale.getDefault()).format(Date()); textSize = 22f; typeface = Typeface.DEFAULT_BOLD }.also { fgViews.add(it) }
        val daySmall = TextView(this).apply { text = SimpleDateFormat("EEE, MMM", Locale.getDefault()).format(Date()); textSize = 11f }.also { fgViews.add(it) }
        moodV = TextView(this).apply { text = "Calm"; textSize = 22f; typeface = Typeface.DEFAULT_BOLD }.also { fgViews.add(it) }
        val moodS = TextView(this).apply { text = "Jarvis' read of the chat"; textSize = 11f }.also { fgViews.add(it) }
        val wr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(card("WEATHER", wTemp, wSky), card("TODAY", dayBig, daySmall), card("MOOD", moodV, moodS)).forEach { wr.addView(it, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(6) }) }
        home.addView(wr, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })
        // modes
        home.addView(section("MODES"))
        home.addView(chipRow(listOf("music" to "Music", "study" to "Study", "journal" to "Journal", "docs" to "Documents", "" to "Off"), modeChips) { id ->
            if (id == "docs") showTab(2) else { store.mode = id; applyTheme(); if (JarvisService.running) startService(Intent(this, JarvisService::class.java).putExtra("role_changed", true)) else startJarvis()
                Toast.makeText(this, if (id.isEmpty()) "Mode off" else "$id mode on", Toast.LENGTH_SHORT).show() } })
        home.addView(section("ROLE"))
        home.addView(chipRow(Roles.presets.map { it.id to it.title.replace(" (default)", "") }, roleChips) { id ->
            store.roleId = id; applyTheme(); if (JarvisService.running) startService(Intent(this, JarvisService::class.java).putExtra("role_changed", true)) })
        home.addView(section("THEME"))
        home.addView(chipRow(Themes.all.map { it.id to it.name }, themeChips) { id -> store.themeId = id; applyTheme() })
        home.addView(section("AVATAR"))
        home.addView(chipRow(listOf("face" to "Anime boy", "orb" to "Orb core", "s0" to "Mine 1", "s1" to "Mine 2", "s2" to "Mine 3", "s3" to "Mine 4"), styleChips) { id ->
            if (id.startsWith("s") && !File(filesDir, "avatar_${id.drop(1)}.png").exists()) { pickSlot = id.drop(1).toInt(); pickImage.launch("image/*") } else { store.avatarStyle = id; applyTheme() } })
        home.addView(section("ASK JARVIS"))
        home.addView(input("Ask Jarvis anything…") { t -> send(t) })

        // ================= CHAT (+ Coding) =================
        val chat = page(); val seg = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val chatPane = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; val codePane = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        seg.addView(btn("Chat") { chatPane.visibility = View.VISIBLE; codePane.visibility = View.GONE }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(6) })
        seg.addView(btn("Coding") { chatPane.visibility = View.GONE; codePane.visibility = View.VISIBLE }, LinearLayout.LayoutParams(0, -2, 1f))
        chat.addView(seg)
        chatBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; chatScroll = ScrollView(this).apply { addView(chatBox) }
        chatPane.addView(chatScroll, LinearLayout.LayoutParams(-1, 0, 1f)); chatPane.addView(input("Message Jarvis…") { t -> send(t) })
        codeOut = TextView(this).apply { setPadding(0, dp(10), 0, 0) }.also { fgViews.add(it) }
        val codeIn = edit("Describe the website, app page or game to build…", ""); codeIn.minLines = 5; codeIn.gravity = Gravity.TOP
        codePane.addView(codeIn); codePane.addView(btn("Build and preview") { saveFn(); codeOut.text = "Working…"; scope.launch { codeOut.text = Creator.website(this@MainActivity, store.apiKey, codeIn.text.toString(), false) } })
        codePane.addView(btn("Apply a change to the last build") { saveFn(); codeOut.text = "Working…"; scope.launch { codeOut.text = Creator.website(this@MainActivity, store.apiKey, codeIn.text.toString(), true) } }); codePane.addView(codeOut)
        chat.addView(chatPane, LinearLayout.LayoutParams(-1, 0, 1f)); chat.addView(codePane, LinearLayout.LayoutParams(-1, -2))

        // ================= CREATE =================
        val create = page()
        create.addView(TextView(this).apply { text = "Create"; textSize = 24f; typeface = Typeface.DEFAULT_BOLD }.also { labels.add(it) })
        val prompt = edit("Website or game idea, or your details for a resume / biodata / letter…", ""); prompt.minLines = 4; prompt.gravity = Gravity.TOP
        createOut = TextView(this).apply { setPadding(0, dp(12), 0, 0) }.also { fgViews.add(it) }
        fun run(f: suspend () -> String) { saveFn(); createOut.text = "Working…"; scope.launch { createOut.text = f() } }
        fun acc() = Themes.resolve(store.themeId, Roles.byId(store.roleId)).accent
        create.addView(prompt)
        listOf(btn("Build website / game") { run { Creator.website(this@MainActivity, store.apiKey, prompt.text.toString(), false) } },
            btn("Change the last website") { run { Creator.website(this@MainActivity, store.apiKey, prompt.text.toString(), true) } },
            btn("Resume PDF") { run { Creator.document(this@MainActivity, store.apiKey, "resume", prompt.text.toString(), acc()) } },
            btn("Biodata PDF") { run { Creator.document(this@MainActivity, store.apiKey, "biodata", prompt.text.toString(), acc()) } },
            btn("Letter PDF") { run { Creator.document(this@MainActivity, store.apiKey, "letter", prompt.text.toString(), acc()) } },
            btn("Report PDF") { run { Creator.document(this@MainActivity, store.apiKey, "report", prompt.text.toString(), acc()) } }).forEach(create::addView)
        create.addView(createOut)

        // ================= SETTINGS =================
        val set = page(); val sc = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        sc.addView(TextView(this).apply { text = "Settings"; textSize = 24f; typeface = Typeface.DEFAULT_BOLD }.also { labels.add(it) })
        permCard = TextView(this).apply { setPadding(dp(14), dp(10), dp(14), dp(10)); textSize = 13f }.also { cards.add(it); fgViews.add(it) }
        sc.addView(permCard, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        sc.addView(lab("THEMES")); themeGrid = GridLayout(this).apply { columnCount = 2 }; sc.addView(themeGrid)
        val ux = edit("Grid X % (default 50)", (store.gridX * 100).toInt().toString()); val uy = edit("Grid Y % (default 68)", (store.gridY * 100).toInt().toString())
        val us = edit("Grid size % (default 38)", (store.gridSize * 100).toInt().toString()); val usp = edit("Pattern speed ms (default 900)", store.patternSpeed.toString())
        val key = edit("Gemini API key", store.apiKey, true); val name = edit("Your name", store.userName); val pat = edit("Pattern dots 1-9, e.g. 14753", store.pattern, true)
        val voiceSp = Spinner(this).apply { adapter = ArrayAdapter(context, android.R.layout.simple_spinner_dropdown_item, listOf("Role default") + Roles.VOICES); setSelection(if (store.voice.isEmpty()) 0 else Roles.VOICES.indexOf(store.voice) + 1) }
        val styleSp = Spinner(this).apply { adapter = ArrayAdapter(context, android.R.layout.simple_spinner_dropdown_item, Roles.STYLES); setSelection(Roles.STYLES.indexOf(store.emoStyle).coerceAtLeast(0)) }
        val auto = check("Auto-switch role by my mood", store.autoMood); val ov = check("Floating orb + captions over other apps", store.overlay)
        val an = check("Message reading: speak new notifications", store.announceNotifs); val vl = check("Only my voice can run sensitive actions", store.requireVoiceLock)
        val sv = check("Save conversation on this phone (encrypted)", store.saveChat)
        val pauseLbl = lab("REPLY PAUSE: ${store.pauseTenths / 10f}–${store.pauseTenths / 10f + 0.5f} s")
        val pause = SeekBar(this).apply { max = 25; progress = store.pauseTenths - 5; setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { pauseLbl.text = "REPLY PAUSE: ${(p + 5) / 10f}–${(p + 5) / 10f + 0.5f} s" }
            override fun onStartTrackingTouch(s: SeekBar?) {}; override fun onStopTrackingTouch(s: SeekBar?) {} }) }
        val provSp = Spinner(this).apply { adapter = ArrayAdapter(context, android.R.layout.simple_spinner_dropdown_item, Llm.all.map { it.name }); setSelection(Llm.all.indexOfFirst { it.id == store.provider }.coerceAtLeast(0)) }
        val provKey = edit("Key for this provider", store.providerKey(store.provider), true); val provOut = TextView(this).apply { textSize = 12f }.also { fgViews.add(it) }
        provSp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { val pr = Llm.all[pos]; store.provider = pr.id; provKey.setText(store.providerKey(pr.id)); provOut.text = pr.note }
            override fun onNothingSelected(p: AdapterView<*>?) {} }
        val links = Accounts.names.associateWith { n -> edit("$n @handle or link", Accounts.load(store)[n.lowercase()] ?: "") }
        saveFn = { store.apiKey = key.text.toString().trim(); store.userName = name.text.toString().trim().ifEmpty { "Friend" }
            store.pattern = pat.text.toString().filter { it in '1'..'9' }; ux.text.toString().toIntOrNull()?.let { store.gridX = it.coerceIn(10, 90) / 100f }; uy.text.toString().toIntOrNull()?.let { store.gridY = it.coerceIn(10, 90) / 100f }; us.text.toString().toIntOrNull()?.let { store.gridSize = it.coerceIn(15, 85) / 100f }; usp.text.toString().toIntOrNull()?.let { store.patternSpeed = it.coerceIn(250, 2500) }; store.autoMood = auto.isChecked; store.overlay = ov.isChecked
            store.announceNotifs = an.isChecked; store.requireVoiceLock = vl.isChecked; store.saveChat = sv.isChecked; store.pauseTenths = pause.progress + 5
            store.voice = if (voiceSp.selectedItemPosition == 0) "" else Roles.VOICES[voiceSp.selectedItemPosition - 1]; store.emoStyle = Roles.STYLES[styleSp.selectedItemPosition]
            Accounts.save(store, links.mapKeys { it.key.lowercase() }.mapValues { it.value.text.toString() })
            store.provider = Llm.all[provSp.selectedItemPosition].id; store.setProviderKey(store.provider, provKey.text.toString().trim()) }
        listOf(lab("SETUP  (do these once)"),
            btn("1. Enable Accessibility (phone control)") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
            btn("2. Display over other apps") { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) },
            btn("3. Keep alive (Samsung / One UI)") { batteryExempt() },
            btn("4. Notification access (message reading)") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) },
            btn("5. All files access") { startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))) },
            lab("AI PROVIDER (builders, documents, summaries, vision)"), provSp, btn("Get free key (opens the website)") { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(Llm.byId(store.provider).keyUrl))) }, provKey, provOut,
            btn("Test this key") { store.setProviderKey(store.provider, provKey.text.toString().trim()); provOut.text = "Testing…"; scope.launch { provOut.text = withContext(Dispatchers.IO) { Llm.test(store) } } },
            lab("GEMINI KEY (live voice and screen agent)"), key, lab("YOUR NAME"), name, lab("SCREEN-LOCK PATTERN (ENCRYPTED)"), pat, lab("PATTERN POSITION (used only if the lock screen grid cannot be detected)"), ux, uy, us, usp,
            lab("VOICE (applies to every role; Hindi/Hinglish are spoken by any voice)"), voiceSp, lab("EMOTION STYLE"), styleSp,
            auto, ov, an, vl, sv, pauseLbl, pause,
            btn("Test unlock now (locks the phone, max 3 tries)") { saveFn(); Toast.makeText(this, "Locking the phone and testing unlock…", Toast.LENGTH_LONG).show(); Thread { val r = Phone(this, store).selfTestUnlock(); runOnUiThread { Toast.makeText(this, r, Toast.LENGTH_LONG).show(); status.text = r } }.start() },
            btn("Enroll my voice (stop Jarvis first, talk 8 s)") { askPerms(); Toast.makeText(this, "Speak normally for 8 seconds…", Toast.LENGTH_SHORT).show()
                VoiceLock(store).enroll(8) { ok -> runOnUiThread { Toast.makeText(this, if (ok) "Voice saved. Turn on the checkbox." else "Not enough speech heard, try again", Toast.LENGTH_LONG).show() } } },
            lab("SAVED ACCOUNTS (public links only, no logins)")).forEach(sc::addView)
        links.values.forEach(sc::addView)
        val slotSp = Spinner(this).apply { adapter = ArrayAdapter(context, android.R.layout.simple_spinner_dropdown_item, listOf("Slot 1 (Mine 1)", "Slot 2 (Mine 2)", "Slot 3 (Mine 3)", "Slot 4 (Mine 4)")) }
        val frSp = Spinner(this).apply { adapter = ArrayAdapter(context, android.R.layout.simple_spinner_dropdown_item, listOf("Framing: full body", "Framing: upper body", "Framing: face close-up")); setSelection(listOf("full", "upper", "face").indexOf(store.framing).coerceAtLeast(0)) }
        val cutCb = check("Remove plain light background", store.cutBg)
        sc.addView(lab("YOUR OWN CHARACTER IMAGES (4 slots)")); sc.addView(slotSp); sc.addView(frSp); sc.addView(cutCb)
        listOf(btn("Load image into slot") { store.framing = listOf("full", "upper", "face")[frSp.selectedItemPosition]; store.cutBg = cutCb.isChecked; pickSlot = slotSp.selectedItemPosition; pickImage.launch("image/*") },
            btn("Clear saved conversation") { Chat.log.clear(); store.chatJson = "[]"; refreshChat(); Toast.makeText(this, "Conversation cleared", Toast.LENGTH_SHORT).show() },
            btn("Save settings") { saveFn(); applyTheme(); Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show() },
            btn("Erase all my data") { store.wipe(); Chat.log.clear(); (0..3).forEach { File(filesDir, "avatar_$it.png").delete() }; avatar.photo = null; status.text = "All data erased"; applyTheme() }).forEach(sc::addView)
        set.addView(ScrollView(this).apply { addView(sc) })

        listOf(home, chat, create, set).forEach { v -> tabs.add(v); content.addView(if (v === home || v === create) ScrollView(this).apply { addView(v) } else v, FrameLayout.LayoutParams(-1, -1)) }
        // ================= NAV =================
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        fun navTab(label: String, idx: Int) { val tv = TextView(this).apply { text = label; textSize = 11f; gravity = Gravity.CENTER; letterSpacing = 0.12f; setPadding(0, dp(16), 0, dp(16)); setOnClickListener { showTab(idx) } }
            tabBtns[idx] = tv; bar.addView(tv, LinearLayout.LayoutParams(0, -2, 1f)) }
        navTab("HOME", 0); navTab("CHAT", 1)
        talk = TextView(this).apply { text = "TALK"; textSize = 11f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD; setOnClickListener { if (JarvisService.running) stopJarvis() else startJarvis() } }
        bar.addView(talk, LinearLayout.LayoutParams(dp(64), dp(64)).apply { bottomMargin = dp(4); topMargin = dp(2) })
        navTab("CREATE", 2); navTab("SETTINGS", 3)
        col.addView(content, LinearLayout.LayoutParams(-1, 0, 1f)); col.addView(bar)
        frame.addView(col, FrameLayout.LayoutParams(-1, -1))

        // ================= SPLASH =================
        splash = FrameLayout(this).apply { setBackgroundColor(0xFF000000.toInt()); isClickable = true }
        val sl = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        val so = OrbView(this).apply { state = "speaking" }
        sl.addView(so, LinearLayout.LayoutParams(dp(220), dp(220)))
        sl.addView(TextView(this).apply { text = "J A R V I S"; textSize = 34f; setTextColor(0xFFC9A227.toInt()); typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD); gravity = Gravity.CENTER })
        sl.addView(TextView(this).apply { text = "Think  ·  Talk  ·  Get things done"; textSize = 13f; setTextColor(0xFFE8C766.toInt()); gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(26)) })
        sl.addView(TextView(this).apply { text = "Voice  ·  Vision  ·  Smart actions  ·  Private"; textSize = 11f; setTextColor(0xFF8C7A3A.toInt()); gravity = Gravity.CENTER })
        splash.addView(sl, FrameLayout.LayoutParams(-1, -1)); frame.addView(splash, FrameLayout.LayoutParams(-1, -1))
        setContentView(frame); loadAvatar(); applyTheme(); showTab(0); refreshChat()
        ui.postDelayed({ splash.animate().alpha(0f).setDuration(450).withEndAction { splash.visibility = View.GONE }.start() }, 1700)
    }

    private fun send(t: String) {
        if (!JarvisService.running) { Toast.makeText(this, "Press START (or TALK) first", Toast.LENGTH_SHORT).show(); return }
        sendBroadcast(Intent("com.jarvis.SEND_TEXT").setPackage(packageName).putExtra("t", t))
    }

    private fun showTab(i: Int) { curTab = i
        tabs.map { if (it.parent is ScrollView) it.parent as View else it }.forEachIndexed { k, v -> v.visibility = if (k == i) View.VISIBLE else View.GONE }
        applyTheme()
    }

    private fun refreshChat() {
        chatBox.removeAllViews(); val th = Themes.resolve(store.themeId, Roles.byId(store.roleId))
        Chat.log.forEach { (user, t) ->
            val tv = TextView(this).apply { text = t; setTextColor(if (user) (if (th.light) 0xFFFFFFFF.toInt() else th.bgTop) else (if (th.light) 0xFF1B1B1B.toInt() else 0xFFFFFFFF.toInt())); textSize = 14f; setPadding(dp(12), dp(8), dp(12), dp(8))
                background = box(if (user) th.accent else 0x33000000, th.accent, 12); maxWidth = dp(290) }
            chatBox.addView(tv, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(8); gravity = if (user) Gravity.END else Gravity.START })
        }
        chatScroll.post { chatScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun buildThemeGrid(th: Theme) {
        themeGrid.removeAllViews()
        Themes.all.forEach { t0 ->
            val t = Themes.resolve(t0.id, Roles.byId(store.roleId)); val sel = store.themeId == t0.id
            val cell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(5), dp(5), dp(5), dp(8)); setOnClickListener { store.themeId = t0.id; applyTheme() } }
            cell.addView(ThemePreview(this, t, sel), LinearLayout.LayoutParams(-1, dp(96)))
            cell.addView(TextView(this).apply { text = t0.name; textSize = 12f; setTextColor(if (th.light) 0xFF1B1B1B.toInt() else -1) })
            themeGrid.addView(cell, GridLayout.LayoutParams().apply { width = (resources.displayMetrics.widthPixels - dp(36)) / 2; height = -2 })
        }
    }

    private fun applyTheme() {
        val r = Roles.byId(store.roleId); val th = Themes.resolve(store.themeId, r); val a = th.accent
        val fg = if (th.light) 0xFF1B1B1B.toInt() else 0xFFFFFFFF.toInt()
        bgView.theme = th; orb.accent = a; avatar.accent = a
        val st = store.avatarStyle
        orb.visibility = if (st == "orb") View.VISIBLE else View.GONE; avatar.visibility = if (st == "orb") View.GONE else View.VISIBLE
        loadAvatar()
        title.setTextColor(a); roleName.text = r.title.replace(" (default)", "").uppercase(); roleName.setTextColor(a)
        greet.text = SimpleDateFormat("H", Locale.getDefault()).format(Date()).toInt().let { h -> (if (h < 12) "Good morning" else if (h < 17) "Good afternoon" else if (h < 21) "Good evening" else "Good night") } + ", " + store.userName
        fgViews.forEach { it.setTextColor(fg); if (it is EditText) it.setHintTextColor((fg and 0x00FFFFFF) or 0x66000000) }
        ready.setTextColor(a); labels.forEach { it.setTextColor(a) }
        buttons.forEach { it.setTextColor(a); it.background = box(if (th.light) 0x14000000 else 0x22000000, a) }
        cards.forEach { it.background = box(if (th.light) 0x14000000 else 0x33000000, (a and 0x00FFFFFF) or 0x77000000, 14) }
        fun chip(m: Map<String, TextView>, on: String) = m.forEach { (id, v) -> val s = id == on; v.setTextColor(if (s) (if (th.light) 0xFFFFFFFF.toInt() else th.bgTop) else a); v.background = box(if (s) a else 0x22000000, a) }
        chip(roleChips, r.id); chip(themeChips, store.themeId); chip(styleChips, st); chip(modeChips, store.mode)
        tabBtns.forEach { (i, v) -> v.setTextColor(if (i == curTab) (if (th.light) 0xFFFFFFFF.toInt() else th.bgTop) else a); v.setBackgroundColor(if (i == curTab) a else 0x33000000) }
        talk.setTextColor(if (th.light) 0xFFFFFFFF.toInt() else th.bgTop); talk.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(a) }
        buildThemeGrid(th); updatePerms()
        window.statusBarColor = th.bgTop; window.navigationBarColor = th.bgBottom
    }

    private fun updatePerms() {
        fun f(b: Boolean) = if (b) "ON " else "OFF"
        val listeners = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: ""
        permCard.text = "Phone control (Accessibility):  ${f(JarvisAccessibilityService.inst != null)}\n" +
            "Screen-lock automation (pattern saved):  ${f(store.pattern.length >= 4)}\n" +
            "Message reading (notification access):  ${f(listeners.contains(packageName))}\n" +
            "Open apps / floating orb (display over apps):  ${f(Settings.canDrawOverlays(this))}\n" +
            "Keep alive (battery unrestricted):  ${f(getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName))}\n" +
            "Files and folders (all files access):  ${f(Environment.isExternalStorageManager())}\n" +
            "Only-my-voice lock:  ${f(store.requireVoiceLock && store.voiceprint.isNotBlank())}"
    }

    private var pickSlot = 0
    private fun loadAvatar() {
        val st = store.avatarStyle; avatar.framing = store.framing
        avatar.photo = if (st.length == 2 && st[0] == 's') File(filesDir, "avatar_${st[1]}.png").takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path) } else null
    }
    /** Turns a plain white/grey background (and checkerboards) around the character transparent, starting from the image edges. */
    private fun cutout(src: Bitmap): Bitmap {
        val bmp = src.copy(Bitmap.Config.ARGB_8888, true); val w = bmp.width; val h = bmp.height; val px = IntArray(w * h); bmp.getPixels(px, 0, w, 0, 0, w, h)
        val seen = BooleanArray(w * h); val q = ArrayDeque<Int>()
        fun bg(c: Int): Boolean { val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c); return minOf(r, g, b) > 185 && maxOf(r, g, b) - minOf(r, g, b) < 24 }
        fun push(x: Int, y: Int) { if (x < 0 || y < 0 || x >= w || y >= h) return; val k = y * w + x; if (seen[k] || !bg(px[k])) return; seen[k] = true; q.addLast(k) }
        for (x in 0 until w) { push(x, 0); push(x, h - 1) }; for (y in 0 until h) { push(0, y); push(w - 1, y) }
        while (q.isNotEmpty()) { val k = q.removeLast(); px[k] = 0; val x = k % w; val y = k / w; push(x + 1, y); push(x - 1, y); push(x, y + 1); push(x, y - 1) }
        bmp.setPixels(px, 0, w, 0, 0, w, h); return bmp
    }
    private fun importAvatar(uri: Uri) {
        try { var bmp = contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it) }
            val sc = 900f / maxOf(bmp.width, bmp.height); if (sc < 1f) bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * sc).toInt(), (bmp.height * sc).toInt(), true)
            if (store.cutBg) bmp = cutout(bmp)
            File(filesDir, "avatar_$pickSlot.png").outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            store.avatarStyle = "s$pickSlot"; loadAvatar(); applyTheme(); Toast.makeText(this, "Saved in slot ${pickSlot + 1}", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { Toast.makeText(this, "Could not read that image", Toast.LENGTH_SHORT).show() }
    }

    private fun askPerms() = ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE,
        Manifest.permission.READ_CONTACTS, Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.CAMERA, Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_EXTERNAL_STORAGE), 1)

    private fun batteryExempt() {
        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isIgnoringBatteryOptimizations(packageName)) startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        else Toast.makeText(this, "Samsung: Settings > Battery > Background usage limits > Never sleeping apps > add Jarvis", Toast.LENGTH_LONG).show()
    }
    override fun onResume() { super.onResume(); updatePerms()
        scope.launch { Weather.get(this@MainActivity)?.let { wTemp.text = it.first; wSky.text = it.second } } }
    override fun onRequestPermissionsResult(r: Int, p: Array<out String>, g: IntArray) { super.onRequestPermissionsResult(r, p, g)
        scope.launch { Weather.get(this@MainActivity)?.let { wTemp.text = it.first; wSky.text = it.second } } }
    override fun onStart() { super.onStart()
        val f = IntentFilter().apply { addAction("com.jarvis.STATUS"); addAction("com.jarvis.EMOTION"); addAction("com.jarvis.TEXT") }
        ContextCompat.registerReceiver(this, rx, f, ContextCompat.RECEIVER_NOT_EXPORTED) }
    override fun onStop() { saveFn(); unregisterReceiver(rx); super.onStop() }
    override fun onDestroy() { scope.cancel(); super.onDestroy() }
}
